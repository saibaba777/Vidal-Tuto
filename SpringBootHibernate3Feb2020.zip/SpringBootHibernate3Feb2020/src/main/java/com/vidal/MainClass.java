package com.vidal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.vidal.config.HibernateConfig;
import com.vidal.model.Customer;

@SpringBootApplication
public class MainClass {
	
	public static void main(String[] args) {
		SpringApplication.run(MainClass.class, args);
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(HibernateConfig.class);
		Customer customer = context.getBean(Customer.class);
		customer.getCustomerName();
		
	}
}
