package com.vidal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vidal.dao.CustomerDAO;
import com.vidal.model.Customer;

@Service("customerService")
public class CustomerService {

	@Autowired
	private CustomerDAO customerDAO;
	
	@Transactional
	public List<Customer> getAllCustomers(){
		List<Customer> list = customerDAO.getAllCustomers();
		return list;
	}
	
	@Transactional
	public Customer addCustomer(Customer cust){
		customerDAO.addCustomer(cust);
		return cust;
	}
}
