package com.vidal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vidal.model.Customer;
import com.vidal.service.CustomerService;

@Controller
public class CustomerController{
	
	@Autowired
	private CustomerService customerService;
	
	@RequestMapping(value="/getAllCustomers",method= {RequestMethod.POST,RequestMethod.GET})
	public String getAllCustomer(Model model) {
		System.out.println("Inside getAllCustomer()");
		List<Customer> list = customerService.getAllCustomers();
		model.addAttribute("customer",new Customer());
		model.addAttribute("savedList", list);
		return "customerDetails";
	}
	
	@RequestMapping(value="/addCustomer",method= {RequestMethod.POST,RequestMethod.GET})
	public String addCustomer(Model model,@ModelAttribute("customer") Customer customer) {
		if(customer.getId()==0) {
			System.out.println("Inside addCustomer()");
			customerService.addCustomer(customer); 
		}
		return "redirect:/getAllCustomers";
	}	
}
