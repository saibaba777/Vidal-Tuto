package com.vidal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="CUSTOMER")
public class Customer {
	
	@Id
	@Column(name="ID")
	@GeneratedValue(strategy=GenerationType.TABLE)
	private int id;
	@Column(name="CUST_NAME")
	private String customerName;
	@Column(name="EMAIL")
	private String email;
	
	public Customer() {
		super();
	}
	
	public Customer(String customerName, String email) {
		super();
		this.customerName = customerName;
		this.email = email;
	}
	
	@Override
	public String toString() {
		return "Customer [id=" + id + ", customerName=" + customerName + ", email=" + email + "]";
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
}
