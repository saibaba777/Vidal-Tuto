package com.vidal.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.vidal.model.Customer;

@Configuration
@EnableTransactionManagement
//@ComponentScan(value="com.vidal.model")
public class HibernateConfig {

	@Value("${spring.datasource.driver-class-name}")
	private String driverName;
	@Value("${spring.datasource.url}")
	private String url;
	@Value("${spring.datasource.username}")
	private String userName;
	@Value("${spring.datasource.password}")
	private String password;
	@Value("${spring.jpa.database-platform}")
	private String dialect;
	@Value("${hibernate.hbm2ddl.auto}")
	private String hbm2ddl;
	@Value("${spring.jpa.show-sql}")
	private String showsql;
	
	@Bean
	public DataSource getDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driverName);
		dataSource.setUrl(url);
		dataSource.setUsername(userName);
		dataSource.setPassword(password);
		return dataSource;
	}
	@Bean
	public LocalSessionFactoryBean getSessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(getDataSource());
		sessionFactory.setAnnotatedClasses(Customer.class);
		Properties hibProps = new Properties();
		hibProps.setProperty("spring.jpa.database-platform", dialect);
		hibProps.setProperty("spring.jpa.show-sql", showsql);
		hibProps.setProperty("hibernate.hbm2ddl.auto", hbm2ddl);
		sessionFactory.setHibernateProperties(hibProps);
		return sessionFactory;
	}
	@Bean
	public HibernateTransactionManager getTransactionManager() {
		HibernateTransactionManager txManager = new HibernateTransactionManager();
		txManager.setSessionFactory(getSessionFactory().getObject());
		return txManager;
	}
	/*@Bean
	public Customer getCustomer() {
		return new Customer();
	}*/
}
