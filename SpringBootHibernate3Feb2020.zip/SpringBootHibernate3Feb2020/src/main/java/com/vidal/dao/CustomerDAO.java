package com.vidal.dao;

import java.util.List;

import com.vidal.model.Customer;

public interface CustomerDAO {

	public List<Customer> getAllCustomers();
	public Customer addCustomer(Customer cust);
	
}
