package com.sa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sa.model.Customer;
import com.sa.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	@RequestMapping(value="/getAllCustomers",method=RequestMethod.GET,headers = "Accept=application/json")
	public List<Customer> getAllCustomer(Model model){
		System.out.println("Inside getAllCustomer controller");
		List<Customer> list = customerService.getAllCustomer();
		model.addAttribute("customers", new Customer());
		model.addAttribute("listOfCustomers", list);
		return list;
	}
	
	@RequestMapping(value="/getCustomer/{id}",method=RequestMethod.GET,headers = "Accept=application/json")
	public void getCustomer(@PathVariable int id) {
		System.out.println("Inside getCustomer controller");
		customerService.getCustomer(id);
	}
	@RequestMapping(value="/addCustomer",method=RequestMethod.POST,headers = "Accept=application/json")
	public Customer addCustomer(@RequestBody Customer customer) {
		System.out.println("Inside addCustomer controller");
		return customerService.addCustomer(customer);
	}
	@RequestMapping(value="/updateCustomer",method=RequestMethod.PUT,headers = "Accept=application/json")
	public Customer updateCustomer(@RequestBody Customer customer) {
		System.out.println("Inside updateCustomer controller");
		return customerService.updateCustomer(customer);
	}
	@RequestMapping(value="/deleteCustomer/{id}",method=RequestMethod.POST,headers = "Accept=application/json")
	public void deleteCustomer(@PathVariable int id) {
		System.out.println("Inside deleteCustomer controller");
		customerService.deleteCustomer(id);
	}
}
