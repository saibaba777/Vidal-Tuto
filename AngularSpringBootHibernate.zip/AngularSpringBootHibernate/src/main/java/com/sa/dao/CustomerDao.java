package com.sa.dao;

import java.util.List;
import com.sa.model.Customer;

public interface CustomerDao {
	
	public List<Customer> getAllCustomer();
	public Customer getCustomer(int id);
	public Customer addCustomer(Customer customer);
	public void updateCustomer(Customer customer);
	public void deleteCustomer(int id);
	
}
