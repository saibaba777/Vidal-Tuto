package com.sa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sa.dao.CustomerDao;
import com.sa.model.Customer;

@Service
public class CustomerService {

	@Autowired
	CustomerDao customerDao;
	
	public List<Customer> getAllCustomer() {
		return customerDao.getAllCustomer();
	}
	public Customer getCustomer(int id) {
		return customerDao.getCustomer(id);
	}
	public Customer addCustomer(Customer customer) {
		return customerDao.addCustomer(customer);
	}
	public Customer updateCustomer(Customer customer) {
		customerDao.updateCustomer(customer);
		return customer;
	}
	public void deleteCustomer(int id) {
		customerDao.deleteCustomer(id);
	}
}
