package com.vidal.java8;

import java.util.ArrayList;
import java.util.function.Consumer;

public class ForEachMethod {

	public static void main(String[] args) {
		ArrayList<String> list= new ArrayList<String>();
		list.add("India");
		list.add("USA");
		list.add("Sydney");
		list.add("London");
		
		list.forEach(new Consumer<String>() {
			@Override
			public void accept(String t) {
				System.out.println(t);
			}
		});
	}
}
