package com.example.SpringEurekaServerDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEurekaServerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
