package com.vidal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "USER_TABLE")
public class UserEntity {
    @Column(name = "ID")
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    
    @Column(name = "USER_NAME", nullable = true, length = 255)
    private String name;
  
    @Column(name = "USER_SALARY", nullable = true, length = 10)
    private Integer salary;
  
    protected UserEntity() {
    }
    //constructor, setters and getters omitted for brevity
}