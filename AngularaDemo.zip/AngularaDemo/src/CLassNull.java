
public class CLassNull {

	public static void main(String[] args) {
		
		String val1 = "";
		
		DummyVO dummyVO = new DummyVO();
		System.out.println("val :: "+dummyVO.getValue());
		String a = dummyVO.getValue();
		System.out.println(a);

	}

}
