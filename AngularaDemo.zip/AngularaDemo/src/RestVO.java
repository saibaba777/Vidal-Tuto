
public class RestVO {

	private String status;
	private String polGroupSeqID;
	private String memberSeqID;
	private String statusCode;
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPolGroupSeqID() {
		return polGroupSeqID;
	}
	public void setPolGroupSeqID(String polGroupSeqID) {
		this.polGroupSeqID = polGroupSeqID;
	}
	public String getMemberSeqID() {
		return memberSeqID;
	}
	public void setMemberSeqID(String memberSeqID) {
		this.memberSeqID = memberSeqID;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
}
