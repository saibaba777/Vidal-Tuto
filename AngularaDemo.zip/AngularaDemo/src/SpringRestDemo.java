import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class SpringRestDemo {

	@RequestMapping("/api")
	public RestVO getPolGroupSeqID(@RequestParam(value="memSeqID") String memberSeqID){
		
		System.out.println("Inside SpringRestDemo class");
		RestVO restVO = new RestVO();
		restVO.setPolGroupSeqID("7890657");
		restVO.setStatus("APPROVED");
		restVO.setStatusCode("200 OK");
		
		return restVO;
	}
}
