import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.apache.commons.io.FilenameUtils;
import org.json.JSONArray;
import org.json.JSONException;


public class XmlTest {

	public static void main(String[] args) throws JSONException, IOException {
		
//		File folder = new File("D:/PROJECT DOMESTIC CR/Kvb_MoblieApp_Changes/AngularaDemo/web/reports/document/");//absolute path working
		String pathfromserver = "/home/jboss/ttkproject/web/reports/documents/";
		File folder = new File("D:/PROJECT DOMESTIC CR/Kvb_MoblieApp_Changes/AngularaDemo/web/reports/document/");//pathfromserver
		
		/*URI base= URI.create("D:/PROJECT DOMESTIC CR/Kvb_MoblieApp_Changes/AngularaDemo/");
		URI absolute = URI.create("D:/PROJECT DOMESTIC CR/Selfund_modified/ttkproject/web/reports/document/");
		URI relative = base.relativize(absolute);
		System.out.println(relative);*/
		
//		File folder = new File("https://testtips.vidalhealthtpa.com/vidalhealth/reports/webdocs/default/");
		LinkedHashMap<Object, Object> mapObject = new LinkedHashMap<Object, Object>();
		ArrayList aList = new ArrayList();
//		System.out.println(folder.getPath());
		File[] listFiles = folder.listFiles();
		for (File file : listFiles) {
			if (file.isFile()) {
				String path[] = pathfromserver.split("web");
				String finalPath = path[1]+file.getName();
				System.out.println("final ::::::::::::::  :: "+finalPath);
//				String path = file.getPath();
//				System.out.println("output ::: "+path);
			}
		}
	}
}
