package com.streamjava8;

import java.util.function.Consumer;
import java.util.stream.Stream;

public class StreamOf {

	public static void main(String[] args) {
		Stream<Integer> list = Stream.of(1,90,1,23,45);
		list.forEach(new Consumer<Integer>() {
			@Override
			public void accept(Integer t) {
				Integer k = t;
				System.out.println("k---->"+k);
			}
		});
	}
}
