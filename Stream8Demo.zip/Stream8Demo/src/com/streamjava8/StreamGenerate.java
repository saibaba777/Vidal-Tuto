package com.streamjava8;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class StreamGenerate {

	public static void main(String[] args) {
		
		Stream<Date> date = Stream.generate(()-> {return new Date();});
		date.forEach(new Consumer<Date>() {

			@Override
			public void accept(Date t) {
				//System.out.println(t);
			}
		});
		
		Stream<List<Integer>> list = Stream.generate(()->{return new ArrayList<Integer>();});
		list.forEach(new Consumer<List<Integer>>() {

			@Override
			public void accept(List<Integer> t) {
				System.out.println("ssssss");
			}
			
		});
	}
}
