package com.streamjava8;

import java.util.function.Consumer;
import java.util.stream.Stream;

public class StreamOfArray {

	public static void main(String[] args) {
		
		Stream<Integer> t1 = Stream.of(new Integer[] {1,2,3,14,25,36});
		t1.forEach(new Consumer<Integer>() {

			@Override
			public void accept(Integer t) {
				System.out.println(t);
			}
		});
	}
}
