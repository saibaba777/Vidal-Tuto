package com.streamjava8;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class ListStream {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		for(int i=1;i<=10;i++) {
			list.add(i);
		}
		
		Stream<Integer> s = list.stream();
		s.forEach(new Consumer<Integer>() {
			@Override
			public void accept(Integer i) {
				System.out.println(i);
			}
		});
		
		Stream<Integer> s2 = list.parallelStream();
		s2.forEach(new Consumer<Integer>() {
			@Override
			public void accept(Integer t) {
				System.out.println("parallel stream :: "+t);
			}
		});
	}
}
