<!DOCTYPE html>  
<html lang="en" data-ng-app="app">
<head>
	<meta charset="UTF-8">
	<title>angularjs</title>
</head>
<body data-ng-controller="helloWorldCtrl">
<div class="grid" >{{message}}
<script src="https://code.angularjs.org/1.6.9/angular.js"></script>
<script>
	angular.module("app",[]).controller("helloworldcontroller",function($scope){
	$scope.message="hello world"
	})
</script>
</div>
</body>

<div data-ng-app="app">
	<body data-ng-controller="helloworldctrl">
	<div class="">
	<script>
		angular.module("app",[]).controller("helloworldcontroller",funcion($scope){
			$scope.message="hello world"
		})
	</script>
</div>
</html>