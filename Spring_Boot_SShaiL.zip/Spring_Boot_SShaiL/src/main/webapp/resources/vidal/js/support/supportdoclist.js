/**
 * 
 */
function searchSuppport(){
	  document.forms["supportSearch"].submit(); 
}



