function modifyLinks(type, name)
{
	if(type == 'Link')
		document.forms[0].menulink.value = name;
	else if(type == 'SubLink')
		document.forms[0].sublink.value = name;
	else if(type == 'Tab')
		document.forms[0].submenulink.value = name;
	
	document.forms[0].action=contextpath+"/defaultcontroler";//"defaultcontroler.do?mode=doDefault"
	document.forms[0].submit();
}

function logout(str){
	document.forms[0].status.value = str;
	document.forms[0].action=contextpath+"/logout";
	document.forms[0].submit();
}

function status(str){
	    $.ajax({url: "/vingsproject/status?str="+str, success: function(response){
	        $("#curstatusId").html("<img src='/vingsproject/resources/vidal/images/"+response+".png' alt='shutdown' width='31px' height='31px'>");
	    }});
}

