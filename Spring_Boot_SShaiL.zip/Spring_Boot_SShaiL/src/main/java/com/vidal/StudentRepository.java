package com.vidal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public interface StudentRepository extends JpaRepository<Student,Long>{

	@Query("select s.name from Student s where s.email=:email and s.password=:password")
	    List getStudentName(String email,String password);
	
	@Query("select case when count(*) >= 1 then 'Y' else 'Invalid Login.' end  from Student  where email=:email and password=:password")
		List getValidLogin(String email,String password);
}
