package com.vidal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

@Repository
public class RegisterDAOImpl{

	public List<Register> getUserName(String email, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	public String getValidLogin(String email, String password) {
	//String query = "select case when count(*)>=1 then 'Y' else 'Invalid Login.' end from user1 where email=:email and password=:password";
	
	String query = "select * from register where email="+"'"+email+"'";
	Register register = jdbc.queryForObject(query, BeanPropertyRowMapper.newInstance(Register.class));
	String res = null;
	System.out.println("password :: "+register.getPassword());
	if(password.equals(register.getPassword())) {
		 res = "Valid user";
	}
	else {
		res = "Invalid user"; 
	}
		return res;
	}
	/* Using queryForObject */
	/*public List<Register> getDataByEmail(String email) {
		System.out.println("inside getDataByEmail ---> "+email);
		String select_query = "select * from Register where email="+"'"+email+"'";
		List<Register> register = jdbc.query(select_query, new BeanPropertyRowMapper<Register>(Register.class));
		
		return register;
	}*/
	
	 /*using query */
	public List<Register> getDataByEmail(String email){
		String select_query = "select * from Register where email="+"'"+email+"'";
	    return jdbc.query(select_query,new RowMapper<Register>(){  
	      
	      public Register mapRow(ResultSet rs, int rownumber) throws  SQLException {  
	    	  Register e=new Register();  
	            e.setUserid(rs.getString(1));  
	            e.setName(rs.getString(2));  
	            e.setEmail(rs.getString(3));  
	            e.setPhone(rs.getString(4));
	            return e;  
	          }  
	      });  
	}
	
	/* using queryForList */
	/*public List<Register> getDataByEmail(String email){
		String select_query = "select * from Register where email="+"'"+email+"'";
		List<Register> data = jdbc.queryForList(select_query, Register.class);
		return data;
	}*/
	
	
	public int addNewUser(String userid, String name, String email, String phone, String password) {
		System.out.println("Inside addnewuser dao");
	    String save_query = "insert into register (user_id,name,email,phone,password) values (:user_id,:name,:email,:phone,:password)";
//		  final String save_query = "insert into register  values (?,?,?,?,?)";
	    
		SqlParameterSource params = new MapSqlParameterSource()
				.addValue("user_id", userid)
				.addValue("name", name)
				.addValue("email", email)
				.addValue("phone", phone)
				.addValue("password", password);
		int result = jdbcTemplate.update(save_query, params);
		
		return result;
	}
	
	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;
	
	@Autowired
	private JdbcTemplate jdbc;
}
