/*package com.vidal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;
import javax.validation.constraints.NotNull;

import java.sql.SQLException;
@Configuration
@ConfigurationProperties("oracle")
//@PropertySource(value ="classpath:application.properties")

public class OracleConfiguration {
	
	 @Autowired
	 private Environment env;	
	

	 	@Bean
	    public JdbcTemplate jdbcTemplate(DataSource dataSource)
	    {
	        return new JdbcTemplate(dataSource);
	    }
	 
    @Bean
    DataSource dataSource() throws SQLException {
    	 DriverManagerDataSource dataSource = new DriverManagerDataSource();
    	 
    	 System.out.println("inside datasource() ::: ");
        dataSource.setUsername(env.getProperty("oracle.username"));
        dataSource.setPassword(env.getProperty("oracle.password"));
        dataSource.setUrl(env.getProperty("oracle.url"));
        
        System.out.println("passed un , pwd, url : "+dataSource.getUsername()+":"+dataSource.getPassword()+":"+dataSource.getUrl());
     
       // dataSource.setImplicitCachingEnabled(true);
        //dataSource.setFastConnectionFailoverEnabled(true);
        return dataSource;
    }
}*/