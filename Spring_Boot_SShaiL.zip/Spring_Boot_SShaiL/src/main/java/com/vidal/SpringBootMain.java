package com.vidal;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication(scanBasePackages={"com.vidal", "com.vidal.validation","dao","formbean","model"})
//@EntityScan(value={"com.vidal.Register","com.vidal.User"})
//@EntityScan("com.vidal")
public class SpringBootMain{

	
//	@Autowired
//	StudentRepository repository;
	
	public static void main(String[] args)
	{
		SpringApplication.run(SpringBootMain.class, args);
	}
	
	public void run(String... args) throws Exception {
		/*log.info("list of students :: "+repository.findAll());
		log.info("student save ::: "+repository.save(new Student("SHAIL", "d781234")));
		log.info("student save with id :: "+repository.save(new Student(103L, "BINA", "C34251672")));
		log.info("update student with id 101 :: "+repository.save(new Student(101L, "SATYA", "S9089213")));*/
	}
}
