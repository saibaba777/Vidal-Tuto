$(document).ready(function () {
    	checkTagedOrNot();
        $("#fileId").change(function () {
            var selectedVal = $("#fileId option:selected").val();
            //alert("Hi, your favorite programming language is " + selectedVal);
            document.forms['frmTagId'].tagFileName.value = selectedVal;
			$("#frmTagId").attr('action',contextpath+"/viewpdfdocumnet").submit();
        });
        $("#queueId").change(function () {
            var selectedVal = $("#queueId option:selected").val();
           // alert("Hi, your favorite programming language is " + selectedVal);
            if("PQC" == selectedVal || "PPMC" == selectedVal){
            	$('body').addClass('sidebar');
            	$("#sendmailId").show("slide", {
            		direction: "left"
            	}, 500);
            	$("#vd-overlay").addClass("vd-overlay-side-panel").fadeIn("slow");
            }
            else if("PDC" == selectedVal){
            	if(confirm("Are you sure move to Junk Queue ?."))
            	{
            		$("#frmTagId").attr('action',contextpath+"/savequerydetails").submit();
            	}
            	else{
            		return false;
            	}
            }
        });
        $("#querySendid").click(function (){
        	$("#frmTagId").attr('action',contextpath+"/savequerydetails").submit();
        });
        $('.c_close').click(function () {
            $(this).parents('div.cpopBox').fadeOut();
        });
        $("#backToDashId").click(function (){
        	$("#frmTagId").attr('action',contextpath+"/backtodashboarddetails").submit();
        });
        $("#endId").click(function () {
        	var name,enrollmentID,certificateNo,genderTypeID,policyNbr,employeeNo,companyName;
        	name= document.forms['frmEnrollSearch'].name.value;
        	enrollmentID = document.forms['frmEnrollSearch'].enrollmentID.value;
        	certificateNo = document.forms['frmEnrollSearch'].certificateNo.value;
        	genderTypeID = document.forms['frmEnrollSearch'].genderTypeID.value;
        	policyNbr = document.forms['frmEnrollSearch'].policyNbr.value;
        	employeeNo = document.forms['frmEnrollSearch'].employeeNo.value;
        	companyName = document.forms['frmEnrollSearch'].companyName.value;
        	var showLetest="";
            document.getElementById("endId").innerHTML = "Please Wait....";    
       if($('#checkbox1').is(':checked')){
    	   showLetest = "Y";
       }else{
    	   showLetest = "";
       }
      
        	
        	if(name == "" && enrollmentID == "" && certificateNo == "" && policyNbr == "" && employeeNo == "" && companyName == ""){
        		document.getElementById("endId").innerHTML = "Search";    
        		swal("Please enter atleast one search criteria");
        		return false;
        	}
        	//$('input[name=name]').val()
        	var formData = {
                    'name': name,
        			'enrollmentID': enrollmentID,
        			'certificateNo': certificateNo,
        			'genderTypeID':genderTypeID,
        			'policyNbr': policyNbr,
        			//'insSeqID': $('select[name=insSeqID]').val(),
        			'employeeNo': employeeNo,
        			'companyName': companyName,
        			'showLetest':showLetest
                };
        	 $.ajax({type: 'POST',data: formData,url: contextpath+"/searchenrollment", success: function(response){
        		
        		 document.getElementById("tableGridId").innerHTML =response;
        			document.getElementById("endId").innerHTML ="Search";
        	 }});
        });
        $("#policySearchId").click(function () {
        	var policyNbr,insSeqID,companyName;
        	insSeqID= document.forms['frmPolicySearch'].insSeqID.value;
        	policyNbr = document.forms['frmPolicySearch'].policyNbr.value;
        	companyName = document.forms['frmPolicySearch'].companyName.value;
        	document.getElementById("policySearchId").innerHTML = "Please Wait...."; 
        	
        
        	//$('input[name=name]').val()
        	var formData = {
                    'insSeqID': insSeqID,
        			'policyNbr': policyNbr,
        			'companyName': companyName
                };
        	 $.ajax({type: 'POST',data: formData,url: contextpath+"/searchpolicy", success: function(response){
        		
        		 document.getElementById("tablePolicyGridId").innerHTML =response;
        		 document.getElementById("policySearchId").innerHTML ="Search";
        	 }});
        });
        
        $("#enrlInsCompanyId").click(function () {
        	var insuranceSeqID,companyCodeNbr,tTKBranchCode;
        	insuranceSeqID= document.forms['frmEnrlInsCompany'].insuranceSeqID.value;
        	companyCodeNbr = document.forms['frmEnrlInsCompany'].companyCodeNbr.value;
        	tTKBranchCode = document.forms['frmEnrlInsCompany'].tTKBranchCode.value;
        	document.getElementById("enrlInsCompanyId").innerHTML = "Please Wait....";
        	//$('input[name=name]').val()
        	var formData = {
                    'insuranceSeqID': insuranceSeqID,
        			'companyCodeNbr': companyCodeNbr,
        			'tTKBranchCode': tTKBranchCode
                };
        	 $.ajax({type: 'POST',data: formData,url: contextpath+"/searchinsurance", success: function(response){
        		 document.getElementById("tableInsuranceGridId").innerHTML =response;
        		 document.getElementById("enrlInsCompanyId").innerHTML ="Search";
        	 }});
        });
        $("#hospitalId").click(function () {
        	var address1,stateTypeID,cityTypeID,hospitalName,emplNumber,hospRohiniId;
        	address1= document.forms['frmSelectHospital'].address1.value;
        	stateTypeID = document.forms['frmSelectHospital'].stateTypeID.value;
        	cityTypeID = document.forms['frmSelectHospital'].cityTypeID.value;
        	hospitalName = document.forms['frmSelectHospital'].hospitalName.value;
        	emplNumber = document.forms['frmSelectHospital'].emplNumber.value;
        	hospRohiniId = document.forms['frmSelectHospital'].hospRohiniId.value;
        	document.getElementById("hospitalId").innerHTML = "Please Wait....";
        	var formData = {
                    'address1': address1,
        			'stateTypeID': stateTypeID,
        			'cityTypeID': cityTypeID,
        			'hospitalName': hospitalName,
        			'emplNumber': emplNumber,
        			'hospRohiniId': hospRohiniId,
                };
        	 $.ajax({type: 'POST',data: formData,url: contextpath+"/searchhospital", success: function(response){
        		 document.getElementById("tableHospitalGridId").innerHTML =response;
        		 document.getElementById("hospitalId").innerHTML = "Search";
        	 }});
        });
        $("#policyTypeId").change(function () {
            var selectedVal = $("#policyTypeId option:selected").val();
			$("#frmTagId").attr('action',contextpath+"/changepolicytype").submit();
        });
      
        $("#hospitalCategoryId").change(function() {
        	if ($(this).val() == "Nat") {
        		$("#hospitalPhoneId").show();
        	} else {
        		$("#hospitalPhoneId").hide();
        	}
        	if ($(this).val() == "IntNat") {
        		$("#hospitalPhoneIntId").show();
        	} else {
        		$("#hospitalPhoneIntId").hide();
        	}
        });
        
        $(".btn-tag").on("click", function(event){
        	event.preventDefault();
            var x =$(this).val();
            var selectedVal = $("#fileId option:selected").val();
            x = (x == 'p' ? 80 : (x == 'd' ? 73 : (x == 'h' ? 72 : (x == 'r' ? 82 : (x == 'a' ? 65 : (x == 'b' ? 66 : (x == 'o' ? 79 :"")))))));
            if("NONE" != selectedVal){
            	callTagFile(x,selectedVal);
            }
            else{
        		swal("Please select Hospital Documents file to Tag.");
        	}
        });
        function checkTagedOrNot(){
        	$("#fileId > option").each(function(){
               // alert($(this).text()+" ----  "+$(this).val());
              var result_arr = new Array();
              result_arr = ($(this).val()).split("@");
              if(result_arr.length > 1){
            		  $(this).css('background-color','#D8BFD8');
              }
            });
        	
        }
        
        function KeyPress(e) {
            var evtobj = window.event? event : e;
            //if (evtobj.keyCode == 90 && evtobj.altKey) alert(evtobj.keyCode+"Ctrl+z");
            var x= evtobj.keyCode;
            var selectedVal = $("#fileId option:selected").val();
            if((evtobj.keyCode == 80 && evtobj.altKey) || (evtobj.keyCode == 73 && evtobj.altKey) || (evtobj.keyCode == 72 && evtobj.altKey) || (evtobj.keyCode == 82 && evtobj.altKey) || (evtobj.keyCode == 65 && evtobj.altKey) || (evtobj.keyCode == 66 && evtobj.altKey) || (evtobj.keyCode == 79 && evtobj.altKey))
            {
            	if("NONE" != selectedVal){
            		callTagFile(x,selectedVal);
            	}
            	else{
            		swal("Please select Hospital Documents file to Tag.");
            	}
            		
            }
      	}
      	document.onkeydown = KeyPress;
      	
    });
    
    
    function callTagFile(x,selectedVal){
    	 $.ajax({url: "/vingsproject/tagfile?str="+x+"&filename="+selectedVal, success: function(response){
    		 	var result, result_arr=new Array();
    		 	result_arr = response.split("#");
    		 	$("embed").remove();
    		 	if("No file To Tag!" != result_arr[1])
    		 		$("#embId").after("<embed src='/vingsproject/viewpdf.htm?filename="+result_arr[1]+"' width='100%' height='100%'>");
    		 	else 
    		 		$("#embId").after("<h1 align='center'>No file To Tag!</h1>");
    		 	if('P' == result_arr[0])
		       	 	$("#pId").html("<button type='button' id ='pId' class='btn vd-btn-primary btn-tag' accesskey='p' value='p' style='padding-top: 0px;padding-bottom: 0px;padding-right: 0px;padding-left: 0px;'>Preauth form & ID\'s (p) <span class='tagCount'>"+result_arr[3]+"</span></button>");
    		 	else if('D' == result_arr[0])
    		 		$("#dId").html("<button type='button' id ='dId' class='btn vd-btn-primary btn-tag' accesskey='i' value='d' style='padding-top: 0px;padding-bottom: 0px;padding-right: 0px;padding-left: 0px;'>Discharge Summary (i)<span class='tagCount'>"+result_arr[3]+"</span></button>");
    		 	else if('H' == result_arr[0])
    		 		$("#hId").html("<button type='button' id ='hId' class='btn vd-btn-primary btn-tag' accesskey='h' value='h' style='padding-top: 0px;padding-bottom: 0px;padding-right: 0px;padding-left: 0px;'>Hospital Main Bill (h)<span class='tagCount'>"+result_arr[3]+"</span></button>");
    		 	else if('R' == result_arr[0])
    		 		$("#rId").html("<button type='button' id ='rId' class='btn vd-btn-primary btn-tag' accesskey='r' value='r' style='padding-top: 0px;padding-bottom: 0px;padding-right: 0px;padding-left: 0px;'>Report on Test (r)<span class='tagCount'>"+result_arr[3]+"</span></button>");
    		 	else if('A' == result_arr[0])
    		 		$("#aId").html("<button type='button' id ='aId' class='btn vd-btn-primary btn-tag' accesskey='a' value='a' style='padding-top: 0px;padding-bottom: 0px;padding-right: 0px;padding-left: 0px;'>Approval Mails (a)<span class='tagCount'>"+result_arr[3]+"</span></button>");
    		 	else if('B' == result_arr[0])
    		 		$("#bId").html("<button type='button' id ='bId' class='btn vd-btn-primary btn-tag' accesskey='b' value='b' style='padding-top: 0px;padding-bottom: 0px;padding-right: 0px;padding-left: 0px;'>Other Bills (b)<span class='tagCount'>"+result_arr[3]+"</span></button>");
    		 	else if('O' == result_arr[0])
    		 		$("#oId").html("<button type='button' id ='oId' class='btn vd-btn-primary btn-tag' accesskey='o' value='o' style='padding-top: 0px;padding-bottom: 0px;padding-right: 0px;padding-left: 0px;'>Other Docs (o)<span class='tagCount'>"+result_arr[3]+"</span></button>");
    		 	
	        	$("#fileId > option").each(function(){
	               if($(this).val() == selectedVal){
	             		  $(this).text(result_arr[2]); $(this).val(result_arr[2]);$(this).css('background-color','#D8BFD8');
	               }
	             });
	        	if("No file To Tag!" != result_arr[1])
    		 		$("#fileId").val(result_arr[1]);
	        	else
	        		$("#fileId").val("NONE");
		    }});
    	 
    }
    
    function testFun12345(){
    	
   	 	var selectedVal = $("#fileId option:selected").val();
    }

    function toggle(sortid,str)
    {
    	//$('#childId').val(str);
        //$('#sortId').val(sortid);
    	var controlerpath ="/searchenrollment";
    	if(str == 'tdPolicy')
    		controlerpath ="/searchpolicy";
    	if(str == 'tdInsurance')
    		controlerpath ="/searchinsurance";
    	else if(str == 'tdHospital')
    		controlerpath ="/searchhospital";
    	else if(str == 'tdCorporate')
    		controlerpath ="/searchcorporate"
    	
        $.ajax({url: contextpath+controlerpath+"?sortId="+sortid+"&child"+str, success: function(response){
        	if(str == "tdPolicy")
        		document.getElementById("tablePolicyGridId").innerHTML =response;
        	else if(str == "tdInsurance")
        		document.getElementById("tableInsuranceGridId").innerHTML =response;
        	else if(str == "tdHospital")
        		document.getElementById("tableHospitalGridId").innerHTML =response;
        	else if(str == "tdCorporate")
        		document.getElementById("corpcompTableGrid").innerHTML =response;
        	else
        		document.getElementById("tableGridId").innerHTML =response;
   	 }});
    }
    
    function pageIndex(pagenumber,str){
    	var controlerpath ="/searchenrollment";
    	if(str == 'tdPolicy')
    		controlerpath ="/searchpolicy";
    	if(str == 'tdInsurance')
    		controlerpath ="/searchinsurance";
    	else if(str == 'tdHospital')
    		controlerpath ="/searchhospital";
    	
        $.ajax({url: contextpath+controlerpath+"?pageId="+pagenumber+"&child="+str, success: function(response){
        	if(str == "tdPolicy")
        		document.getElementById("tablePolicyGridId").innerHTML =response;
        	else if(str == "tdInsurance")
        		document.getElementById("tableInsuranceGridId").innerHTML =response;
        	else if(str == "tdHospital")
        		document.getElementById("tableHospitalGridId").innerHTML =response;
        	else
        		document.getElementById("tableGridId").innerHTML =response;
      	}});
    }

    //function to display next set of pages
    function PressForward(str)
    { 
    	var controlerpath ="/searchenrollment";
    	if(str == "tdPolicy")
    		controlerpath ="/searchpolicy";
    	else if(str == 'tdHospital')
    		controlerpath ="/searchhospital";
    	else if(str == "tdInsurance")
    		controlerpath ="/searchinsurance";
    	
    	$.ajax({url: contextpath+controlerpath+"/forward?child="+str, success: function(response){
    		if(str == "tdPolicy")
        		document.getElementById("tablePolicyGridId").innerHTML =response;
    		else if(str == "tdInsurance")
        		document.getElementById("tableInsuranceGridId").innerHTML =response;
    		else if(str == "tdHospital")
        		document.getElementById("tableHospitalGridId").innerHTML =response;
        	else
        		document.getElementById("tableGridId").innerHTML =response;
     	}});
    }//end of PressForward()

    //function to display previous set of pages
    function PressBackWard(str)
    { 
    	var controlerpath ="/searchenrollment";
    	if(str == "tdPolicy")
    		controlerpath ="/searchpolicy";
    	else if(str == 'tdHospital')
    		controlerpath ="/searchhospital";
    	else if(str == "tdInsurance")
    		controlerpath ="/searchinsurance";
    	
    	$.ajax({url: contextpath+controlerpath+"/backward?child="+str, success: function(response){
    		if(str == "tdPolicy")
        		document.getElementById("tablePolicyGridId").innerHTML =response;
    		else if(str == "tdInsurance")
        		document.getElementById("tableInsuranceGridId").innerHTML =response;
    		else if(str == "tdHospital")
        		document.getElementById("tableHospitalGridId").innerHTML =response;
        	else 
        		document.getElementById("tableGridId").innerHTML =response;
     	}});
    }
   
    
    function edit(rownum,str)
    { 
    	$('#childId').val(str);
        $('#rownumId').val(rownum);
    	var postData = [];
    	var f = document.forms["frmTagId"];
    /*	alert(" f "+f.length);*/
    	for(var i=0;i<document.forms["frmTagId"].length;i++){
    		 postData.push(f.elements[i].name + "=" + f.elements[i].value);
    	}
    	

    	var receivedTime,admissionTime,dischargeTime,prevApprovedAmount,admissionType,doctorName;
    	var requestAmount,officeSeqID,priorityTypeID,hospitalCategory,preAuthRecvTypeID,dobonumber;
    	var hospitalPhone,hospitalPhoneInt,preauthSubTypeBenefit,insPhone,hosPhone,remarks,policyMemRemarks;
    	receivedTime= document.forms['frmTagId'].receivedTime.value;
    	admissionTime = document.forms['frmTagId'].admissionTime.value;
    	dischargeTime = document.forms['frmTagId'].dischargeTime.value;
    	prevApprovedAmount = document.forms['frmTagId'].prevApprovedAmount.value;
    	admissionType = document.forms['frmTagId'].admissionType.value;
    	doctorName = document.forms['frmTagId'].doctorName.value;
    	
    	requestAmount = document.forms['frmTagId'].requestAmount.value;
    	officeSeqID = document.forms['frmTagId'].officeSeqID.value;
    	priorityTypeID = document.forms['frmTagId'].priorityTypeID.value;
    	hospitalCategory = document.forms['frmTagId'].hospitalCategory.value;
    	preAuthRecvTypeID = document.forms['frmTagId'].preAuthRecvTypeID.value;
    	dobonumber = document.forms['frmTagId'].dobonumber.value;
    	
    	hospitalPhone = document.forms['frmTagId'].hospitalPhone.value;
    	hospitalPhoneInt = document.forms['frmTagId'].hospitalPhoneInt.value;
    	preauthSubTypeBenefit = document.forms['frmTagId'].preauthSubTypeBenefit.value;
    	insPhone = document.forms['frmTagId'].insPhone.value;
    	hosPhone = document.forms['frmTagId'].hosPhone.value;
    	remarks = document.forms['frmTagId'].remarks.value;
    	policyMemRemarks = document.forms['frmTagId'].policyMemRemarks.value;
    	
    	var formData = {
                'receivedTime': receivedTime,
    			'admissionTime': admissionTime,
    			'dischargeTime': dischargeTime,
    			'prevApprovedAmount': prevApprovedAmount,
    			'admissionType': admissionType,
    			'doctorName': doctorName,
    			
    			'requestAmount': requestAmount,
    			'officeSeqID': officeSeqID,
    			'priorityTypeID': priorityTypeID,
    			'hospitalCategory': hospitalCategory,
    			'preAuthRecvTypeID': preAuthRecvTypeID,
    			'dobonumber': dobonumber,
    			
    			'hospitalPhone': hospitalPhone,
    			'hospitalPhoneInt': hospitalPhoneInt,
    			'preauthSubTypeBenefit': preauthSubTypeBenefit,
    			'insPhone': insPhone,
    			'hosPhone': hosPhone,
    			'remarks': remarks,
    			'policyMemRemarks': policyMemRemarks,
            };
    	 $.ajax({type: 'POST',data: formData,url: contextpath+"/setgenaraldetails", success: function(response){
    		
    	 }});
    	
        if(str == "tdPolicy"){
        	document.forms['frmPolicySearch'].child.value = str;
        	document.forms['frmPolicySearch'].rownum.value = rownum;
        	$("#frmPolicySearch").attr('action',contextpath+"/searchpolicy/select").submit();
        }
        else if(str == "tdInsurance"){
        	document.forms['frmEnrlInsCompany'].child.value = str;
        	document.forms['frmEnrlInsCompany'].rownum.value = rownum;
        	$("#frmEnrlInsCompany").attr('action',contextpath+"/searchinsurance/select").submit();
        }
        else if(str == "tdHospital"){
        	document.forms['frmSelectHospital'].child.value = str;
        	document.forms['frmSelectHospital'].rownum.value = rownum;
        	$("#frmSelectHospital").attr('action',contextpath+"/searchhospital/select").submit();
        }else if(str == "tdCorporate"){
        	document.forms['frmEnrlCorporate'].child.value = str;
        	document.forms['frmEnrlCorporate'].rownum.value = rownum; 
        	$("#frmEnrlCorporate").attr('action',contextpath+"/searchCorporateData").submit();
        }
        
        else{
        	document.forms['frmEnrollSearch'].child.value = str;
        	document.forms['frmEnrollSearch'].rownum.value = rownum;
        	$("#frmEnrollSearch").attr('action',contextpath+"/searchenrollment/select").submit();
        }
    }
   
    
    function clearEnrollmentID(){
    	$("#frmTagId").attr('action',contextpath+"/clearenrollmentid").submit();
    }
    
    function onDocumentLoad(){
    /*	alert("tcs")*/
    /*	$("input").attr('maxlength','60');*/
             var selVal = $("#policyTypeId option:selected").val();
             var preAuthTypeId = $("#preAuthTypeId").val();
             //alert(preAuthTypeId+" Hi, your favorite programming language is " + selVal);
             var addInfo = document.getElementById("additionalinfo");
     		//var empNoLabel =document.getElementById("empNoLabel");
     		var dateOfJoiing =document.getElementById("dateOfJoiing");
     		var empName =document.getElementById("empName");
     		var schemeName = document.getElementById("schemeName");
     		
     		
     		if(selVal == 'COR'){
     			if(preAuthTypeId == 'MAN'){
     			   addInfo.style.display="";
     			   //empNoField.style.display="";
     			   dateOfJoiing.style.display="";
     		   	   empName.style.display="";
     			}
     		}
     		else if(selVal == 'NCR' && preAuthTypeId == "MAN")
    		{
    			//document.getElementById("corporate").style.display="";
    			addInfo.style.display="";
    			schemeName.style.display="";
    			empNoLabel.style.display="none";
    			//empNoField.style.display="none";
    		  	empName.style.display="none";
    		}
     		else{
     		   $('#policyHolNameId').attr('readOnly',false);
     		   addInfo.style.display="none";
     		   schemeName.style.display="none";
     		   //empNoLabel.style.display="none";
     		   //empNoField.style.display="none";
     		   empName.style.display="none";
     		}
            
        
    }
    
    function onSelectState(stateId) {
        var stateid =stateId;
        if(stateid == ''){
            $('#cityTypeId')[0].options.length = 0;
            $("#cityTypeId").prepend("<option value='' selected='selected'>City</option>");
            return false;
        }else{
            var path=contextpath+"/preauth/doCityList.htm?stateId="+stateid+"";

            $.ajax({
                url :path,
                success : function(data) {
                    var myselect1=document.getElementById("cityTypeId");
                    while (myselect1.hasChildNodes()) {
                        myselect1.removeChild(myselect1.firstChild);
                    }
                    // myselect1.options.add(new Option("City",""));
                    var res1 = data.split("#");
                    for(var i=0;i<res1.length-1;i++){
                        var code=res1[i].split("@");
                        myselect1.options.add(new Option(code[1],code[0]));
                    }
                    var options = $("#cityTypeId option");                    // Collect options
                    options.detach().sort(function(a,b) {               // Detach from select, then Sort
                        var at = $(a).text();
                        var bt = $(b).text();
                        return (at > bt)?1:((at < bt)?-1:0);            // Tell the sort function how to order
                    });
                    options.appendTo("#cityTypeId");
                    $("#cityTypeId").prepend("<option value='' selected='selected'>City</option>");

                }
            });
        }
    } 