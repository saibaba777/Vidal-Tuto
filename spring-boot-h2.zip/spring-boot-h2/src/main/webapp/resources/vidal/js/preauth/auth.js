//checked
function showhideReasonAuth1(){	
  selObj = document.getElementById("statusTypeID");
  var selVal = selObj.options[selObj.selectedIndex].value;
   var approvedAmt1;
	var ppnYN=document.getElementById("ppn").value;
	var CopayCalc=document.getElementById("copayCalc").value;
 
	 if(selVal == 'REJ')// For showing the Clause button
  {
		
  		document.getElementById("clauseRemarks").style.display=""; 
  		document.getElementById("Reason").style.display=""; 
	    document.forms['authForm'].action = contextpath+"/Pre-Authorization/Authorization/dogetFormValues?statusValue="+selVal;
	    document.forms['authForm'].submit();

  }
  else
  {
  	 	document.getElementById("clauseRemarks").style.display="none"; // for clause  value
  	 }//end of else
	 
	 
	 if(selVal == 'REJ' || selVal == 'PCN' || selVal == 'PCO')
	  {
		
	    document.getElementById("Reason").style.display="";
	   // if(strReset!='Reset')
	     document.getElementById("reasonTypeID").value='';
	    document.getElementById("status").value='Y';
	    document.forms['authForm'].action = contextpath+"/Pre-Authorization/Authorization/dogetFormValues?statusValue="+selVal;
	    document.forms['authForm'].submit();
	  }// end of if(selVal == 'REJ' || selVal == 'PCO')
	  else
	  {
	    document.getElementById("Reason").style.display="none";
	    document.getElementById("status").value="N";
	  }// end of else
  
	 if(selVal == 'APR')// -1
	{
		//var appAmt=parseFloat(document.getElementById("approvedAmount").value);
        // swal("appAmt::"+ appAmt);
         
		var requestedAmt= parseFloat(document.getElementById("requestedAmount").value);
		swal("reqAmt::"+ requestedAmt);
		   approvedAmt1=onSettlementCalculation();//2000
				    
				swal("approvedAmt1 after onSettlementCalculation  :::"+approvedAmt1);
					approvedAmt1=approvedAmt1-CopayCalc;
					
					swal(" show hide hi approvedAmt1::::"+approvedAmt1);
					//document.getElementById("approvedamt").style.display="";
					document.getElementById("approvedamt1").style.display="";
					document.getElementById("permission").style.display="";
					//document.getElementById("permission1").style.display="";
					if(selVal == 'APR')// -2
					{
						if(approvedAmt1 < requestedAmt)
						{
							document.getElementById("Reason").style.display="";
							//if(strReset!='Reset'){
								document.getElementById("reasonTypeID").value='';
						//	}//end of if(strReset!='Reset')
							document.getElementById("status").value='Y';
						}//end of if(approvedAmt1< requestedAmt)
					//	document.getElementById("approvedamt1").disabled=false;
						document.getElementById("approvedAmount").value = approvedAmt1;
						swal("final approver amount::; :::     "+document.getElementById("approvedAmount").value);
						var afterCopayAmount =parseFloat(document.forms['authForm'].afterCopayAmount.value);
						
						afterCopayAmount = (isNaN(afterCopayAmount) ? 0 : afterCopayAmount);
						
							
						//document.forms['authForm'].mode.value ="dogetFormValues";
					    document.forms['authForm'].action = contextpath+"/Pre-Authorization/Authorization/dogetFormValues?statusValue="+selVal+"&totcopayAmt="+afterCopayAmount;
					    document.forms['authForm'].submit();
					}//end of  if(selVal == 'APR') -2
	         
	}//end of  if(selVal == 'APR')-1
	else{		
						document.getElementById("approvedamt1").style.display="none";
						document.getElementById("permission").style.display="none";
						
	}//end of else

	 if(document.getElementById("completedYN").value === "Y"){
			if(selVal == 'REJ' || selVal == 'APR' || selVal=='PCO')
			{
				document.getElementById("authletter").style.display="";
				document.getElementById("preauthstatus").value='Y';
			}//end of if(selVal == 'REJ' || selVal == 'APR')
			else
			{
				document.getElementById("authletter").style.display="none";
				document.getElementById("preauthstatus").value='N';
			}//end of else
			}
	 if(ppnYN == "Y")
		{
			if(selVal == 'REJ')
			{
				document.getElementById("changereasonstatus").style.display="none";
				document.getElementById("rejchangereasonstatus").style.display="";
			}
			else
			{
				document.getElementById("changereasonstatus").style.display="";
				document.getElementById("rejchangereasonstatus").style.display="none";
			}
		}
	 
	 
	 
	if(selVal == 'INP'){
		
		document.getElementById("discountAmount").readonly=false;
		document.getElementById("copayCalc").readonly=false;
		document.getElementById("copayBufferamount").readonly=false;
		
	}//end of if(selVal == 'INP')
	else{
		if(selVal == 'APR'){
			
			document.getElementById("discountAmount").readonly=true;
			document.getElementById("copayCalc").readonly=true;
			document.getElementById("copayBufferamount").readonly=true;
			document.getElementById("totcopayAmount").disabled=true;
			document.getElementById("totcopayAmount").className="textBox textBoxMedium textBoxDisabled";
														 
		
		}//end of if(selVal == 'APR')
		else{
			
			document.getElementById("discountAmount").readonly=true;
			document.getElementById("copayCalc").disabled=true;
			document.getElementById("copayBufferamount").readonly=true;
			document.getElementById("totcopayAmount").disabled=true;
			document.getElementById("totcopayAmount").className="textBox textBoxMedium textBoxDisabled";
		}//end of else
	}

}// end of function showhideReasonAuth1(selObj)

function onSave()
{  // var memberCopay=0;
	//added for Mail-SMS Template for Cigna
	   
	   //var mailNotifyYN = document.getElementsByName("mailNotifyYN");
	   //alert("mailNotifyYN");
	   if(document.getElementById("mailNotifyYN").checked)
		{
		   alert(" mailNotifyYN :   Y" );
			document.getElementById("mailNotify").value="Y";			
		}
	  
		else
		{
			alert(" mailNotifyYN :   N" );
			document.getElementById("mailNotify").value="N";
		}		
	
	var BankYNValue = document.getElementById("BankYNValue").value;
	alert("5."+BankYNValue);
	var totalValue= document.getElementById("totalAmount").value;
	alert("6."+totalValue);
	//var claimsubgenraltypeid = document.forms['authForm'].claimsubgenraltypeid.value;
	
	//var preRepudiationStatus = document.forms['authForm'].preRepudiationStatus.value;
	//var PreRepLetterYN = document.getElementById("PreRepLetterYN").value;
	   
	/*var preauthsubgenraltypeid = document.getElementById("preauthsubgenraltypeid").value;
	alert("7."+preauthsubgenraltypeid);*/
	//var cashBenefitCignaYN = document.forms['authForm'].cignaCashBenefityn.value;
	var copayCalc=document.getElementById("copayCalc").value;
	alert("8."+copayCalc);
	
	var dedYN = document.getElementById("policy_deductable_yn").value;
	alert("9 dedYN:::"+dedYN);
	
	document.getElementById("balanceDedAmount").readonly=true;	
	policydedAmount = parseFloat(document.getElementById("balanceDedAmount").value);
	alert("9."+policydedAmount);
	var approvedAmt;
	var maxAlloweAmt = parseFloat(document.getElementById("maxAllowedAmt").value);
	alert("11."+maxAlloweAmt);
	
	 selObj = document.getElementById("statusTypeID");
	  var selVal = selObj.options[selObj.selectedIndex].value;
	   alert("10:  "+selVal);
    
    var requestedAmt= parseFloat(document.getElementById("requestedAmount").value);
    alert("12.Req amt:"+requestedAmt);
    
    var discountAmount = document.getElementById("discountAmount").value;
    alert("13.dis Amt:"+discountAmount);
    
   // var depositAmt= trim(document.forms['authForm'].depositAmt.value);
    var copayAmount = document.getElementById("copayAmount").value;
   alert("14.copayAmt"+copayAmount); 
   
   // var vcopayAmount = document.getElementById("vcopayAmount").value;
   
	/*if( document.forms['authForm'].memberCopayFlag.value=='Y')
	{
		var memberCopay = document.getElementById("memberCopay").value;
    }											  
  */
																 
	 
   //Added as per kOC 1216B Change request copayBufferamount
    var copayBufferamount = document.getElementById("copayBufferamount").value;
    alert("15.copay buffer:"+copayBufferamount);
	//KOC 1286 for OPD
    var opdAmount= document.getElementById("strOPDAmountYN").value;
    alert("16.opd"+opdAmount);
    
	var opdValue = document.getElementById("availDomTrtLimit").value;
	alert("17.opdValue:"+opdValue);
	
	//var enhancedSumInsuredYN=document.forms['authForm'].enhancedSumInsuredYN.value;
	//KOC 1286 for OPD
	var rohiniIdYN =document.getElementById("hospRohiniIdFalg").value;
	alert("18.rohiniIdYN:"+rohiniIdYN);
	
	var availSumInsuredAmt= parseFloat(document.getElementById("availSumInsured").value);
	alert("19.availSumInsuredAmt"+availSumInsuredAmt); 
	var topPopPolicyYN = document.getElementById("topPopPolicyYN").value;
	alert("20.topPopPolicyYN:::"+topPopPolicyYN); /*not used in onSettlement()*/
	
	if((rohiniIdYN == "Y") && (document.getElementById("statusTypeID").value == "APR"))
		{
		alert("�Rohini ID� is not available for the selected Hospital; Hence Claim/Preauth cannot be Approved�");
		return false;
		}
	  if(document.forms[1].statusTypeID.value == 'APR')
	    {

	//approvedAmt=  parseFloat(document.forms[1].approvedAmount.value);
	var approvedAmt1 = onSettlementCalculation();//2000
	
	approvedAmt = parseFloat(approvedAmt1);
	alert("approvedAmt 7::"+approvedAmt);
	
	approvedAmt =approvedAmt-copayCalc;
	alert("approvedAmt 8:::"+approvedAmt);
	
	/*if(topPopPolicyNY == 'Y')
		{
		
		topUpPolicyDef();
		}*/
	//Added code for OPD case for pre-auth
	
	if((preauthsubgenraltypeid == 'OPD') && (opdAmount != 'N'))
    {
		alert("inside if OPD");
        if(approvedAmt > opdValue)
        {
        alert("Approved Amount is exceeding OPD Limit");
            return false;
        }

    }
	
    if((preauthsubgenraltypeid == 'OPD') && (opdAmount == 'N'))
    {
    	alert("inside if OPD 2");
        if(approvedAmt > opdValue)
        {
        alert("Approved Amount is exceeding OPD Limit");
            return false;
        }

    }
    
    /* *******if(claimsubgenraltypeid != 'OPD')
    { 
	if(approvedAmt > totalValue)
		{
		alert("Approved Amount is exceeding Approval Limit");
		return false;
		}//end of if(approvedAmt > totalValue)
    }
    
    */
    
    
		if(dedYN !="Y" &&  policydedAmount <= approvedAmt)
	    {
		alert("ddnyn :"+dedYN);
		if(approvedAmt1 ==0)
			{
		alert("Approved Amount is zero,preauth cannot be approved");
		
		return false;
		  }
		}//end of if(approvedAmt ==0)
	
		if(approvedAmt > requestedAmt)//4000>2000
		{
		alert("Approved Amount is exceeding Requested Amount");
		return false;
		}//end of if(approvedAmt > totalValue)
	
		
		/******if(approvedAmt < requestedAmt)
		{
			if(document.forms[1].reasonTypeID.value == "")
			{ 
		alert("Please Select Reason");
		return false;
			}
		}//end of if(approvedAmt > totalValue)
*/	
	    }
	alert("outside if::");
	
	 /*if(document.getElementById("statusTypeID").value == 'REJ'){
		 alert("21.topPopPolicyYN:::"+topPopPolicyYN); not used in onSettlement()
		if(topPopPolicyYN == 'Y'){
    		topUpPolicyDef();
    	}
    	
    }
  function topUpPolicyDef(){
    	if(requestedAmt == 0){
    		alert("Requested Amount is zero,request cannot be approved");
			return false;
    	}
    	else if(availSumInsuredAmt < requestedAmt)
    		{
    			alert("Please check Top-Up Policy available");
    		}
    }*/

	
 
   var disamt = discountAmount.substring(discountAmount.indexOf(".")+1,discountAmount.length);
   alert("disamt:::"+disamt);
   var copayamt = copayAmount.substring(copayAmount.indexOf(".")+1,copayAmount.length);
   alert("copayamt:::"+copayamt);
    /*var vcopayamt = vcopayAmount.substring(vcopayAmount.indexOf(".")+1,vcopayAmount.length);
    alert("vcopayamt:::"+vcopayamt);
*/



//Added as per KOC 1216 b change Request
    //copayBufferamount
    var copaybufferamt = copayBufferamount.substring(copayBufferamount.indexOf(".")+1,copayBufferamount.length);
    alert("copaybufferamt:::"+copaybufferamt);
    var copaybufferamtflag = copayBufferamount.indexOf(".");
    alert("copaybufferamtflag:::"+copaybufferamtflag);
    //Added as per KOC 1216 b change Request

    var disamtflag = discountAmount.indexOf(".");
    alert("disamtflag:::"+disamtflag); //-1 when REJ
    
    //var copayamtflag = copayAmount.indexOf(".");
    
    //var vcopayamtflag = vcopayAmount.indexOf(".");
    trimForm(document.forms['authForm']);
	document.getElementById("discountAmount").readonly=false;
	document.getElementById("copayAmount").readonly=false;
	//document.forms['authForm'].vcopayAmount.disabled=false;
	document.getElementById("copayCalc").readonly=false;										   
		/*if( document.forms['authForm'].memberCopayFlag.value=='Y')
    {
        document.forms['authForm'].memberCopay.disabled=false;
	} 	*/	
	//added as per koC 1216B change request
	document.getElementById("copayBufferamount").disabled=false;
	
	//if(!JS_SecondSubmit){
	if((disamt > 0) && (disamtflag > 0 ))
	{
		alert('Discount Amt. / Co-Pay Amt. should be whole number');
		
	}

	//end of if((disamt > 0 || copayamt > 0) && (disamtflag > 0 || copayamtflag > 0))
	
	else
	{
		document.forms['authForm'].action = contextpath+"/Pre-Authorization/doSave";
		//JS_SecondSubmit=true;
		document.forms['authForm'].submit();
	
		
		if(document.getElementById("statusTypeID").value == 'APR')
	    {
			
			
		
			//var lateOrNoCopayAmount = document.getElementById("lateOrNoCopayAmount").value;
			//document.forms['authForm'].mode.value ="doSave";
			documentvalue=BankYNValue;
			//document.forms['authForm'].lateornocopayval.value=lateOrNoCopayAmount;
			document.forms['authForm'].action = contextpath+"/Pre-Authorization/doSave";
			JS_SecondSubmit=true;
			document.forms['authForm'].submit();
			}
	 
		else
		{ 
			//var lateOrNoCopayAmount = document.getElementById("lateOrNoCopayAmount").value;
			//document.forms['authForm'].mode.value ="doSave";
			document.getElementById("BankYNValue").value=BankYNValue;
			//document.forms['authForm'].lateornocopayval.value=lateOrNoCopayAmount;
			document.forms['authForm'].action = contextpath+"/Pre-Authorization/doSave";
			JS_SecondSubmit=true;
			document.forms['authForm'].submit();
		}
	}//end of else
	//}
	//}//end of if(!JS_SecondSubmit)	
	
}//end of onSave()



function mailNotify()
{
	swal("inside   mailNotify" +document.getElementById("mailNotify").value);
		if(document.getElementById("mailNotify").value=="Y")
			{
			document.getElementById("mailNotifyYN").checked = true;
			document.getElementById("mailNotify").value = "Y";
			}
		
		else
			{
			document.getElementById("mailNotifyYN").checked = false;			
			document.getElementById("mailNotify").value = "N";
	        }
	
	
}// end of mailNotify()

function displayReason()
{
	
		var statusId=document.getElementById("statusTypeID").value; 
		swal("statusId: displayReason  :"+statusId);
		
		if(statusId == "APR")
		{
			var approvedAmt1;
			swal("statusId: displayReason  :"+statusId);
	    	/*document.getElementById("taxAmtPaid").disabled=true;
			document.getElementById("taxAmtPaid").className="textBox textBoxMedium textBoxDisabled";*/
			var finalApprovedAmt1 = onFinalAppAmtCalculation();
				if(finalApprovedAmt1<0)
			{
				finalApprovedAmt1 = 0.00;
			}
			finalApprovedAmt1=finalApprovedAmt1-copayCalc;
			//document.getElementById("finalApprovedAmt").value=finalApprovedAmt1;
			
			var requestedAmt= parseFloat(document.getElementById("requestedAmount").value);
			approvedAmt1=onSettlementCalculation1();
			
			//var strReset='undefined';
			
			//showhideReasonAuth1(strReset); 
		
			 
		}
		
	
}// end of display reason()::   



function onSettlementCalculation1()
{
	var approvedAmount;
	regexp=/^[0-9]*\.*[0-9]*$/;
	//var depositAmt= trim(document.forms[1].depositAmt.value);
	//var calcButDispYN = document.forms[1].calcButDispYN.value;
    var finalApprovedAmt= parseFloat(document.forms[1].approvedAmount.value);
    alert("finalApprovedAmt:::"+finalApprovedAmt);
    //var taxAmtPaid = (document.forms[1].taxAmtPaid.value.length);
	var maxAllowedAmt = document.forms[1].maxAllowedAmt.value;
	alert("maxAllowedAmt:::"+maxAllowedAmt);
	//added as per KOC 1216B Change request
	var copayBufferamount = parseInt(document.getElementById("copayBufferamount").value);
	alert("copayBufferamount:::"+copayBufferamount);	
	/*if(maxAllowedAmt==0  && calcButDispYN =='N')
	{
		approvedAmount=0.00;
		return approvedAmount;
	}//end of if(maxAllowedAmt==0  && calcButDispYN =='N')
*/	if((finalApprovedAmt ==0) || (finalApprovedAmt=='NaN') )
	{
		approvedAmount=0.00;
		return approvedAmount;
		
	}//end of if((finalApprovedAmt ==0) || (finalApprovedAmt=='NaN'))

	/*if((regexp.test(document.forms[1].depositAmt.value)) && (finalApprovedAmt !=0))
	{
		
		if(depositAmt > finalApprovedAmt)
		{
			alert("Deposit Amount should not be greater than Final Approved Amt.");
			approvedAmount=0.00
			return approvedAmount;
		}//end of if(depositAmt > finalApprovedAmt)
		else
		{
			approvedAmount=finalApprovedAmt-depositAmt;
			return Math.round(approvedAmount);
		}//end of else
	}//end of if(depositAmt != "" && regexp.test(depositAmt))
*/	return approvedAmount;
}//end of function onSettlementCalculation1()	



//checked
function onSettlementCalculation()
{
	var maxAllowedAmt = parseFloat(document.getElementById("maxAllowedAmt").value);
	var discountAmount = parseInt(document.getElementById("discountAmount").value);
	var copayAmount = parseInt(document.getElementById("totcopayAmount").value);
	document.getElementById("balanceDedAmount").readonly=true;								   
//	var vcopayAmount = parseInt(document.forms['authForm'].vcopayAmount.value);
	policydedAmount = parseFloat(document.getElementById("balanceDedAmount").value);
	alert("policydedAmount:: "+policydedAmount);//0 for APR
	var dedYN = document.forms['authForm'].policy_deductable_yn.value; 
	var bufferCopay = parseFloat(document.getElementById("copayBufferamount").value);
	var afterCopayAmount =parseFloat(document.getElementById("afterCopayAmount").value);
	copayAmount = (isNaN(copayAmount) ? 0 : copayAmount);
														 
	bufferCopay = (isNaN(bufferCopay) ? 0 : bufferCopay);
	afterCopayAmount = (isNaN(afterCopayAmount) ? 0 : afterCopayAmount);
	
	policydedAmount = (isNaN(policydedAmount) ? 0 : policydedAmount);
																					 
	afterCopayAmount=copayAmount;
	document.getElementById("afterCopayAmount").value=afterCopayAmount;
	swal("afterCopayAmount2::"+afterCopayAmount);//0
	regexp=/^[0-9]*\.*[0-9]*$/;
	var disCopayAmt = 0.00;
	
	if(maxAllowedAmt !=0){
		
			if((discountAmount != "" && regexp.test(discountAmount)) && (copayAmount != "" && regexp.test(copayAmount))){
			disCopayAmt = disCopayAmt+discountAmount+copayAmount+policydedAmount+bufferCopay; //changed 2dy
			if(disCopayAmt > maxAllowedAmt){
			if(dedYN!="Y")
			{
			    swal("Sum of Discount and Copay Amount should not be greater than Max. Allowed Amt.");
			}
			
			
			maxAllowedAmt = 0.00;
			return maxAllowedAmt;
			}//end of if(disCopayAmt > maxAllowedAmt)
			else{
				maxAllowedAmt =  maxAllowedAmt-disCopayAmt;
				return Math.round(maxAllowedAmt);
			}//end of else
		}//end of if
		else if((discountAmount != "" && regexp.test(discountAmount)) && (copayAmount != "" && regexp.test(copayAmount))&& (copayBufferamount != "" && regexp.test(copayBufferamount)) ){
			
	disCopayAmt = disCopayAmt+discountAmount+copayAmount+copayBufferamount;

			if(disCopayAmt > maxAllowedAmt){
			    swal("Sum of Discount and Copay Amount should not be greater than Max. Allowed Amt.");
				maxAllowedAmt = 0.00;
				return maxAllowedAmt;
			}//end of if(disCopayAmt > maxAllowedAmt)
			else{
				maxAllowedAmt =  maxAllowedAmt-disCopayAmt;
				return Math.round(maxAllowedAmt);
			}//end of else
		}//end of else if
		else{
		
			if(discountAmount != "" && regexp.test(discountAmount)){
				
				if(discountAmount > maxAllowedAmt){
					swal("Discount Amount is exceeding MaxAllowed Amount");
					maxAllowedAmt = 0.00;
					return maxAllowedAmt;
				}//end of if(discountAmount > maxAllowedAmt)
				else{
				if(maxAllowedAmt < (discountAmount+policydedAmount+bufferCopay))
					{
						//changed --1---
						maxAllowedAmt=0.00;
						swal("inside max allowed 1:"+maxAllowedAmt);
						//changed --1---
						return maxAllowedAmt;
					}
					else
					{
						maxAllowedAmt = maxAllowedAmt - (discountAmount+policydedAmount+bufferCopay);
						swal("inside max allowed2:"+maxAllowedAmt);
						return maxAllowedAmt;
					}
					
					return Math.round(maxAllowedAmt);
				}//end of else
			}//end of if(discountAmount != "" && regexp.test(discountAmount))
			
            	if((afterCopayAmount + bufferCopay) != "" && regexp.test(afterCopayAmount  + bufferCopay)){
				if((afterCopayAmount + bufferCopay)  > maxAllowedAmt){
					swal(" Total Copay Amount is exceeding MaxAllowed Amount");
					maxAllowedAmt = 0.00;
					return maxAllowedAmt;
				}//end of if(copayAmount > maxAllowedAmt)
				else{
					if(maxAllowedAmt < (afterCopayAmount + policydedAmount + bufferCopay))
					{
						//--changed --2dy --
						maxAllowedAmt = 0.00;
						return maxAllowedAmt;
					}
					else
					{
					
						maxAllowedAmt = maxAllowedAmt-(afterCopayAmount + policydedAmount + bufferCopay);
						return maxAllowedAmt;
					}
					}//end of else
			}//end of if(totcopayAmount != "" && regexp.test(totcopayAmount))
				if(maxAllowedAmt > policydedAmount)
			{
				
				maxAllowedAmt = maxAllowedAmt - policydedAmount;
				return maxAllowedAmt;
			}
			else
			{
				//changed --3--
				
				maxAllowedAmt = 0.00;
				return maxAllowedAmt;
			}
			//modified as per KOC 1216B chane Request
			
		}//end of else
		
	
	return maxAllowedAmt;
	}//end of if(maxAllowedAmt !=0)
	
	else{
		
		if(maxAllowedAmt<0){
			
			maxAllowedAmt = 0.00;
		}//end of if(maxAllowedAmt<0)
		return maxAllowedAmt;
	}//end of else
	//return maxAllowedAmt;

}//end of function onSettlementCalculation()

function onCopayBreakUp()
{    
	var statusId=document.getElementById("statusTypeID").value; 
	if(statusId == "APR")
	{		
	document.getElementById("discountAmount").readonly=false;
	}
	//document.forms['authForm'].mode.value ="doCopayBreakUp";
	document.forms['authForm'].action= contextpath+"/Pre-Authorization/Authorization/doCopayBreakUp";
    document.forms['authForm'].submit();
}

function calculatetotCopay()
{

	//var copayAmount = document.getElementById("copayAmount").value;
	//var bufferCopay = document.getElementById("copayBufferamount").value;
	// var totcopayAmount = document.getElementById("totcopayAmount").value;

	var discountAmount = parseFloat(document.getElementById("discountAmount").value);
	discountAmount = (isNaN(discountAmount) ? 0 : discountAmount);


	var copayAmount = parseFloat(document.getElementById("totcopayAmount").value);
																									   
	//var vcopayAmount = parseFloat(document.forms['authForm'].vcopayAmount.value);
	var bufferCopay = parseFloat(document.getElementById("copayBufferamount").value);
	var afterCopayAmount =parseFloat(document.getElementById("afterCopayAmount").value);
	//var lateOrNoCopayAmount = parseFloat(document.forms['authForm'].lateOrNoCopayAmount.value);//added for copay4intimation CR

	var copayTempAmount = parseFloat(document.getElementById("copayTempAmount").value);
																			 
	var vcopayTempAmount = parseFloat(document.getElementById("vcopayTempAmount").value);
	var copayBuffTempAmount = parseFloat(document.getElementById("copayBuffTempAmount").value);
	//var lateOrNoCopayTempAmount = parseFloat(document.forms['authForm'].lateOrNoCopayTempAmount.value);//added for copay4intimation CR
	
	copayAmount = (isNaN(copayAmount) ? 0 : copayAmount);
	afterCopayAmount = (isNaN(afterCopayAmount) ? 0 : afterCopayAmount);													 
	//vcopayAmount = (isNaN(vcopayAmount) ? 0 : vcopayAmount);
	bufferCopay = (isNaN(bufferCopay) ? 0 : bufferCopay);
//	lateOrNoCopayAmount = (isNaN(lateOrNoCopayAmount) ? 0 : lateOrNoCopayAmount);

	if(copayAmount != 0)
	{
		document.getElementById("copayAmount").value=trim(document.getElementById("copayAmount").value);
	}
	if(bufferCopay != 0)
	{

		document.getElementById("copayBufferamount").value=trim(document.getElementById("copayBufferamount").value);
	}
	
	
	if(copayAmount == copayTempAmount)
	{
		if(discountAmount != 0)
		{	
			if(copayTempAmount != 0)
			{
				document.getElementById("copayAmount").value=trim(document.getElementById("copayTempAmount").value);

				copayAmount = (isNaN(copayTempAmount) ? 0 : copayTempAmount);
			}
		}
	}
if(bufferCopay == copayBuffTempAmount)
	{
		if(discountAmount != 0)
		{	
			if(copayBuffTempAmount != 0)
			{

				document.getElementById("copayBufferamount").value=trim(document.getElementById("copayBuffTempAmount").value);

				bufferCopay = (isNaN(copayBuffTempAmount) ? 0 : copayBuffTempAmount);
			}

		}
	}
	// totcopayAmount=copayAmount+bufferCopay+lateOrNoCopayAmount+memberCopay+vcopayAmount;


	//totcopayAmount = (isNaN(totcopayAmount) ? 0 : totcopayAmount);


	//document.forms['authForm'].totcopayAmount.value =totcopayAmount;
	afterCopayAmount=copayAmount+bufferCopay;
	afterCopayAmount = (isNaN(afterCopayAmount) ? 0 : afterCopayAmount);
	document.getElementById("afterCopayAmount").value =afterCopayAmount;
	onFinalAppAmtCalculation();
}

function onSelectPreClause()
{
	//document.forms[1].mode.value="doSelectClause";
	//document.forms[1].child.value="Clauses";
	//document.forms[1].action="/SelectRejectoinClause.do";
	document.forms['authForm'].action = contextpath+"/Pre-Authorization/doSelectClause";
	document.forms[1].submit();
}//end of onSelectClause()
function onSend()
{
	var denialGrpReaStatus = document.getElementById("denialGrpReaStatus").value;  //add in controller method sendAuthorization
	var insurerApprovedStatus = document.getElementById("insurerApprovedStatus").value;
	//var clmInsStatus = document.forms[1].clmInsStatus.value;
	//var emailYN = document.forms[1].emailYN.value;
	//var claimTypeID = document.getElementById("claimTypeID").value; 
	 
	
    //document.forms[1].mode.value ="doSendAuthorization";
    document.forms[1].denialGrpReaStatus.value=denialGrpReaStatus;
    document.forms[1].insurerApprovedStatus.value=insurerApprovedStatus;
    document.forms[1].action = contextpath + "/Pre-Authorization/Authorization/doSendAuthorization";
    document.forms[1].submit();
}//end of onSend()

//for genletter button
function onReport()
{
	swal("inside onReport() :::");
	var generateYN = document.getElementById("generateYN").value;
	swal("generateYN ::: "+generateYN);
	  if(generateYN == "N" || generateYN == "" || generateYN == "null")
	  {
		  if(TC_GetChangedElements().length>0)
	    {
			  swal("*Please save the modified data, before Generating Letter");
	      return false;
	    }//end of if(TC_GetChangedElements().length>0)
	 }
		 else if(generateYN == "Y")
    {
			 swal("Please save the modified data, before Generating Letter");
      return false;
    }//end of if(TC_GetChangedElements().length>0)
	
  /*if(document.forms[0].leftlink.value == "Pre-Authorization")
   {*/
      var parameterValue="|"+document.getElementById("preAuthSeqID").value+"|"+document.getElementById("statusTypeID").value+"|PRE|";
      swal("parameterValue :: "+parameterValue);
      var statusID=document.getElementById("statusTypeID").value;  
      swal("statusID :: "+statusID);
      var parameter = "";
      var authno = document.getElementById("authorizationNo").value;
     // var preauthno = document.getElementById("preAuthNo").value;
     // var DMSRefID = document.getElementById("DMSRefID").value;
      var completedYN = document.getElementById("completedYN").value;
      swal("completedYN :: "+completedYN);
      var mailNotifyYN = document.getElementById("mailNotify").value;
      var authTypeID = document.getElementById("authLtrTypeID").value;
      swal("authTypeID :: "+authTypeID);
      var filePath = "D://VINGS PRODUCT//CR FOR AUTHORIZATION//vingsproject//src//main//webapp//WEB-INF//reportsjrxml//generalreports";
      if(statusID == 'APR')
      {      
	      if(authTypeID == 'NIC')
	      {
	    	  swal("inside APR if NIC");
	      	parameter = "doGenerateAuthReport?&reportType=PDF&parameter="+parameterValue+"&fileName=D://VINGS PRODUCT//CR FOR AUTHORIZATION//vingsproject//src//main//webapp//WEB-INF//reportsjrxml//generalreports//CitibankAuthAprLetter.jrxml&reportID=CitiAuthLetter&authorizationNo="+authno+"&completedYN="+completedYN;
	    
	      }//end of if(authTypeID == 'NIC')
	      else
	      {
	    	  swal("inside APR else NIC");
	      	parameter = "doGenerateReport?&reportType=PDF&parameter="+parameterValue+"&fileName=D://VINGS PRODUCT//CR FOR AUTHORIZATION//vingsproject//src//main//webapp//WEB-INF//reportsjrxml//generalreports//AuthAprLetter.jrxml&reportID=AuthLetter&authorizationNo="+authno+"&completedYN="+completedYN+"&finalapprovalYN="+mailNotifyYN;
   	      }//end of else
      }//end of if(statusID == 'APR')
      else if(statusID == 'REJ')
      {
            parameter = "doGenerateReport?&reportType=PDF&parameter="+parameterValue+"&fileName=D://VINGS PRODUCT//CR FOR AUTHORIZATION//vingsproject//src//main//webapp//WEB-INF//reportsjrxml//generalreports//AuthRejLetter.jrxml&reportID=AuthRejLetter&authorizationNo="+authno+"&completedYN="+completedYN;
           
      }//end of else
      else if(statusID == 'PCN')
      {
            parameter = "doGenerateReport?&reportType=PDF&parameter="+parameterValue+"&fileName=D://VINGS PRODUCT//CR FOR AUTHORIZATION//vingsproject//src//main//webapp//WEB-INF//reportsjrxml//generalreports//AuthCanLetter.jrxml&reportID=AuthCanLetter&authorizationNo="+authno+"&completedYN="+completedYN;
           
      }//end of else
   //}//end of if(document.forms[0].leftlink.value == "Pre-Authorization")
      
  var openPage = contextpath + "/Pre-Authorization/Authorization/" + parameter;
  //document.forms['authform'].action = contextpath+"/Pre-Authorization/doGenerateReport";
  var w = screen.availWidth - 10;
  var h = screen.availHeight - 49;
  var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="+w+",height="+h;
  window.open(openPage,'',features);
}//end of onReport()


function onReportCustomerCare()
{
  if(TC_GetChangedElements().length>0)
    {
      alert("Please save the modified data, before Generating Letter");
      return false;
    }//end of if(TC_GetChangedElements().length>0)


    if(document.forms[0].leftlink.value == "Claims")
   {
      var parameterValue="|"+document.forms[1].claimSeqID.value+"|";
      var paymentseqid = "|"+document.forms[1].paymentSeqID.value+"|";
      var parameterValuePCO = document.forms[1].claimSeqID.value;
      var statusID=document.forms[1].statusTypeID.value;
      var authno = document.getElementById("authorizationNo").value;
      //added for Mail-SMS Template for Cigna
      var cigna_Ins_Cust = document.forms[1].cigna_Ins_Cust.value;
      var claimTypeID = document.forms[1].claimTypeID.value;
      var paymentSeqId = document.forms[1].paymentSeqID.value;
   
     
	       if(statusID == 'APR')
	       {
	    	   if(paymentSeqId != "")
	     	  {
	    	   if(claimTypeID=="CTM"){
		    	   if(cigna_Ins_Cust=="Y"){
		     		  
			     		  parameter = "?mode=doGenerateCignaApprovalLtr&reportType=PDF&parameter="+paymentseqid+"&fileName=generalreports/DomesticClaimSettlementLtrPO.jrxml&reportID=CignaClaimAppvlLtrAdv&authorizationNo="+authno;
			    	   		}
			    	   		else if(cigna_Ins_Cust=="G"){
			     		  
			     		  parameter = "?mode=doGenerateCignaApprovalLtr&reportType=PDF&parameter="+paymentseqid+"&fileName=generalreports/ClaimSettlementLtrPO.jrxml&reportID=CignaClaimAppvlLtrAdv&authorizationNo="+authno;
			    	   		}
	    	   } else  if(claimTypeID=="CNH"){
	    		  
		     		  parameter = "?mode=doGenerateComputationCoverLetter&reportType=PDF&parameter="+paymentseqid;
	
	    	    }
	       }//end payment seq id
	    	   else{
	    		   alert("Cheque or EFT details are not updated");
	    		   return false;
	    	   }
	     }//end of if(statusID == 'APR')
    	
      else if(statusID == 'REJ')
      {
    	  if(cigna_Ins_Cust=="Y"){
    		  
    		  parameter = "?mode=doGenerateCignaRejectReport&reportType=PDF&parameter="+parameterValuePCO+"&fileName=generalreports/DomesticClaimRejectLtrPO.jrxml&reportID=CignaClaimRejectLtrPO&authorizationNo="+authno;
    	  }
    	  else if(cigna_Ins_Cust=="G"){
    		  
    		  parameter = "?mode=doGenerateCignaRejectReport&reportType=PDF&parameter="+parameterValuePCO+"&fileName=generalreports/ClaimRejectLtrPO.jrxml&reportID=CignaClaimRejectLtrPO&authorizationNo="+authno;
    		  
    	  }else{
    		  
     		 parameter = "?mode=doGenerateReport&reportType=PDF&parameter="+parameterValue+"&fileName=generalreports/MediClaimCompRej.jrxml&reportID=MediClaimCom&authorizationNo="+authno;
    	  }
    
      }//end of else if(statusID == 'REJ')
      else{
    	  
    	  alert("Not Authorized to generate this Letter");
		   return false;
      }
  
   }//end of else if(document.forms[0].leftlink.value == "Claims")
   var openPage = "/ReportsAction.do"+parameter;
   var w = screen.availWidth - 10;
   var h = screen.availHeight - 49;
   var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="+w+",height="+h;
   window.open(openPage,'',features);
}//end of onReportCustomerCare()


function onFinalAppAmtCalculation()
{
//var calcButDispYN = document.getElementById("calcButDispYN").value;
	
	swal("onFinalAppAmtCalculation::   1");
var maxAllowedAmt = parseFloat(document.getElementById("maxAllowedAmt").value);
var discountAmount = parseFloat(document.getElementById("discountAmount").value);
//added for Policy Deductable 
//if(document.getElementById("claimsubgenraltypeid").value != 'OPD')
//	{
//	policydedAmount = document.getElementById("balanceDedAmount").value;
//	}
//else
	//{
	policydedAmount=0;
	//}

//added for Policy Deductable
	
	
	swal("onFinalAppAmtCalculation:: 2  "+maxAllowedAmt+"    "+discountAmount);
var dedYN = document.getElementById("policy_deductable_yn").value;
//var preauthDiff = document.getElementById("preauthDifference").value;//not using

swal("onFinalAppAmtCalculation:: 3  "+dedYN);
//var preAuthYN = document.getElementById("preauthYN").value;

//Changes were made according to 1216B Change request copayment as totcopayment (copay +copayonbuffer) in this function 
var copayAmount = parseFloat(document.getElementById("totcopayAmount").value);
																								   
//var vcopayAmount = parseFloat(document.forms[1].vcopayAmount.value);
var bufferCopay = parseFloat(document.getElementById("copayBufferamount").value);
var afterCopayAmount =parseFloat(document.getElementById("afterCopayAmount").value);
//var lateOrNoCopayAmount = parseFloat(document.forms[1].lateOrNoCopayAmount.value);//added for copay4intimation CR

copayAmount = (isNaN(copayAmount) ? 0 : copayAmount);
													 
//vcopayAmount = (isNaN(vcopayAmount) ? 0 : vcopayAmount);
bufferCopay = (isNaN(bufferCopay) ? 0 : bufferCopay);
afterCopayAmount = (isNaN(afterCopayAmount) ? 0 : afterCopayAmount);
policydedAmount = (isNaN(policydedAmount) ? 0 : policydedAmount); 
//lateOrNoCopayAmount = (isNaN(lateOrNoCopayAmount) ? 0 : lateOrNoCopayAmount);
/*var memberCopay=0;
if( document.forms[1].memberCopayFlag.value=='Y')
   {
 memberCopay = parseFloat(document.getElementById("memberCopay").value);
memberCopay = (isNaN(memberCopay) ? 0 : memberCopay);

}*/

//copayAmount=copayAmount-(discountAmount*copayAmount/maxAllowedAmt);
//totcopayAmount=copayAmount+bufferCopay+lateOrNoCopayAmount+memberCopay+vcopayAmount;
afterCopayAmount=copayAmount+bufferCopay;


//document.forms[1].totcopayAmount.value=totcopayAmount;
document.getElementById("afterCopayAmount").value=afterCopayAmount;
regexp=/^[0-9]*\.*[0-9]*$/;
var disCopayAmt = 0.00;
//var maxAmt = 0.00;

if(maxAllowedAmt !=0){
	if((discountAmount != "" && regexp.test(discountAmount)) && (afterCopayAmount != "" && regexp.test(afterCopayAmount))){
		//disCopayAmt = disCopayAmt+discountAmount+totcopayAmount;

			disCopayAmt = disCopayAmt+discountAmount+afterCopayAmount+policydedAmount;
			
		if(disCopayAmt > maxAllowedAmt){
			if(dedYN!="Y")
			{
		      swal("Sum of Discount and Copay Amount should not be greater than Approved Amt. (Rs) (Bills)");
			}
			maxAllowedAmt = 0.00;
			return maxAllowedAmt;
		}//end of if(disCopayAmt > maxAllowedAmt)
		else{

			//maxAllowedAmt =  maxAllowedAmt-disCopayAmt;
			//return maxAllowedAmt;
			/*if(preAuthYN=="Y")
			{
				if(preauthDiff > 0)
				{
				   //swal("1.7--:"+maxAllowedAmt);
				
				   maxAllowedAmt = preauthDiff - disCopayAmt; //changed -- 0
				   
				
				   return maxAllowedAmt;
				}
				else if(preauthDiff <= 0)
				{
					//swal("1.8--:"+maxAllowedAmt);
					maxAllowedAmt = 0.00;
					return maxAllowedAmt;
				}
			}
			else
			{
				//swal("1.2--"+maxAllowedAmt);
*/
				maxAllowedAmt =  maxAllowedAmt-disCopayAmt;
				return maxAllowedAmt;
			//}
		}//end of else
	}//end of if
	else{
		if(discountAmount != "" && regexp.test(discountAmount)){
			if(discountAmount > maxAllowedAmt){
				swal("Discount Amount is exceeding Approved Amt. (Rs) (Bills)");
				maxAllowedAmt = 0.00;
				return maxAllowedAmt;
			}//end of if(discountAmount > maxAllowedAmt)
			else{
				//maxAllowedAmt = maxAllowedAmt-discountAmount;
				if(maxAllowedAmt < (discountAmount+policydedAmount))
				{
					//changed --1---
					maxAllowedAmt=0.00;
					//changed --1---
					return maxAllowedAmt;
				}
				else
				{
					//swal("inside else, maxAllowedAmt amount Greater");
					/*if(preAuthYN=="Y")
					{
						if(preauthDiff > 0)
						{
						   //swal("1.7--:"+maxAllowedAmt);
						   maxAllowedAmt = preauthDiff - (discountAmount+policydedAmount) ; //changed -- 1
						   return maxAllowedAmt;
						}
						else if(preauthDiff <= 0)
						{
							//swal("1.8--:"+maxAllowedAmt);
							maxAllowedAmt = 0.00;
							return maxAllowedAmt;
						}
					}
					else
					{*/
						maxAllowedAmt = maxAllowedAmt - (discountAmount+policydedAmount);
						return maxAllowedAmt;							
					//}
					
				}
				//maxAllowedAmt = maxAllowedAmt-discountAmount;//changed
				//swal("1.3--"+maxAllowedAmt);
			
			return maxAllowedAmt;
			}//end of else
		}//end of if(discountAmount != "" && regexp.test(discountAmount))
		if(afterCopayAmount != "" && regexp.test(afterCopayAmount)){
			if(afterCopayAmount > maxAllowedAmt){
				swal("Total Copay Amount is exceeding Approved Amt. (Rs) (Bills)");
				maxAllowedAmt = 0.00;
				return maxAllowedAmt;
			}//end of if(copayAmount > maxAllowedAmt)
			else{
				//maxAllowedAmt = maxAllowedAmt-totcopayAmount;
				if(maxAllowedAmt < (afterCopayAmount + policydedAmount))
				{
					//changed --2--
					maxAllowedAmt = 0.00;
					return maxAllowedAmt;
				}
				else
				{
					/*if(preAuthYN=="Y")
					{
						if(preauthDiff > 0)
						{
						   //swal("1.7--:"+maxAllowedAmt);
						   maxAllowedAmt = preauthDiff - (afterCopayAmount + policydedAmount) ; //changed - 2
						   return maxAllowedAmt;
						}
						else if(preauthDiff <= 0)
						{
							//swal("1.8--:"+maxAllowedAmt);
							maxAllowedAmt = 0.00;
							return maxAllowedAmt;
						}
					}
					else
					{*/
						maxAllowedAmt = maxAllowedAmt-(afterCopayAmount + policydedAmount);
						//swal("1.4--"+maxAllowedAmt);
						return maxAllowedAmt;
					//}						
				}
			//return maxAllowedAmt;
		}//end of else
}//end of if(copayAmount != "" && regexp.test(copayAmount))
if(maxAllowedAmt > policydedAmount)
{
  			/*//swal("1.6--:"+maxAllowedAmt);
			if(preAuthYN=="Y")
			{
				if((preauthDiff > 0)&&(policydedAmount< preauthDiff))
				{
				   //swal("1.7--:"+maxAllowedAmt);
				   maxAllowedAmt = preauthDiff - policydedAmount; //changed - 3
				   return maxAllowedAmt;
				}
				else
				{
					maxAllowedAmt = policydedAmount - preauthDiff ; //changed - 3
					return maxAllowedAmt;
				//}
				if(preauthDiff > 0)
				{
					//swal("1.7--:"+preauthDiff);
					if(policydedAmount >= preauthDiff)
					{
						//swal("1.7.1--:");
						var maxAllowedAmtafterdiff = policydedAmount - preauthDiff ; //changed - 3
						//swal("1.7.1.1--:"+maxAllowedAmtafterdiff);
						if(maxAllowedAmt>=maxAllowedAmtafterdiff)
						{
							return maxAllowedAmt = 0.00;
						}
						else
						{
							return maxAllowedAmt;
						}							
					}
					else if(policydedAmount < preauthDiff)
					{
						//swal("1.7.2--:");
						maxAllowedAmt = preauthDiff - policydedAmount ; //changed - 3
					}
					return maxAllowedAmt;
				}
				else if(preauthDiff <= 0)
				{
					//swal("1.8--:"+preauthDiff);
					maxAllowedAmt = 0.00;
					return maxAllowedAmt;
				}										
			}
			else
			{*/
				maxAllowedAmt = maxAllowedAmt - policydedAmount;
				return maxAllowedAmt;
			//}
	   }
	   else
	   {   
			//changed --3--
			maxAllowedAmt = 0.00;
			return maxAllowedAmt;
	   }
								
	}//end of else
return maxAllowedAmt;
}//end of if(maxAllowedAmt !=0)

else{
	if(maxAllowedAmt<0){
		maxAllowedAmt = 0.00;
	}//end of if(maxAllowedAmt<0)
	return maxAllowedAmt;
}//end of else

//return maxAllowedAmt;
}//end of onFinalAppAmtCalculation()

function discountCopay(){
	var afterCopayAmount=0;
	var maxAllowedAmt = parseFloat(document.getElementById("maxAllowedAmt").value);
	var discountAmount = parseFloat(document.getElementById("discountAmount").value);
	var copayTempAmount = parseFloat(document.getElementById("copayTempAmount").value);
	var copayBuffTempAmount = parseFloat(document.getElementById("copayBuffTempAmount").value);
																			
	var  vcopayTempAmount=parseFloat(document.getElementById("vcopayTempAmount").value);
	 

	/*if(copayTempAmount != 0)
	{
		document.forms[1].copayAmount.value=trim(document.forms[1].copayTempAmount.value);

		copayAmount = (isNaN(copayTempAmount) ? 0 : copayTempAmount);
		swal("copayAmount::::"+copayAmount);
	}*/
	if(copayBuffTempAmount != 0)
	{

		document.getElementById("copayBufferamount").value=trim(document.getElementById("copayBuffTempAmount").value);

		bufferCopay = (isNaN(copayBuffTempAmount) ? 0 : copayBuffTempAmount);
	}
	var copayAmount = parseFloat(document.getElementById("totcopayAmount").value);
	//swal("copayAmount1::::"+copayAmount);																							   
	//var vcopayAmount = parseFloat(document.forms[1].vcopayAmount.value);
	var bufferCopay = parseFloat(document.getElementById("copayBufferamount").value);
	copayAmount = (isNaN(copayAmount) ? 0 : copayAmount);
														 
	//vcopayAmount = (isNaN(vcopayAmount) ? 0 : vcopayAmount);
	bufferCopay = (isNaN(bufferCopay) ? 0 : bufferCopay);
	//totcopayAmount = (isNaN(totcopayAmount) ? 0 : totcopayAmount);
	discountAmount = (isNaN(discountAmount) ? 0 : discountAmount);
 
	
	if(discountAmount != 0)
	{	
		copayAmount=copayAmount-(discountAmount*copayAmount/maxAllowedAmt);
																		
		//vcopayAmount=vcopayAmount-(discountAmount*vcopayAmount/maxAllowedAmt);
		bufferCopay=bufferCopay-(discountAmount*bufferCopay/maxAllowedAmt);
		copayAmount = Math.round(copayAmount);
										  
		//vcopayAmount = Math.round(vcopayAmount);
		bufferCopay = Math.round(bufferCopay);
		if(copayAmount != 0)
		{
			document.getElementById("copayAmount").value=copayAmount;
			document.getElementById("totcopayAmount").value=copayAmount;
	
		
		}
		else
		{
			document.getElementById("copayAmount").value="";
		}
		
		if(bufferCopay != 0)
		{
			document.getElementById("bufferCopay").value=bufferCopay;
		}
		else
		{
			document.getElementById("bufferCopay").value="";
		}
	
  
		
		
		afterCopayAmount=copayAmount+bufferCopay;
		afterCopayAmount = Math.round(afterCopayAmount);

		
	}
	else
	{
		document.getElementById("copayAmount").value=copayAmount;
		document.getElementById("totcopayAmount").value=copayAmount;
		afterCopayAmount=copayAmount+bufferCopay;
		document.getElementById("afterCopayAmount").value=afterCopayAmount;
	}

}//end of discountCopay