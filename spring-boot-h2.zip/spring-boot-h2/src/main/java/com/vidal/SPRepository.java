package com.vidal;

import java.awt.Cursor;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
//import java.util.Optional;









import javax.persistence.NamedStoredProcedureQueries;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;

import oracle.jdbc.OracleTypes;
import oracle.jdbc.oracore.OracleType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Repository;


/*@NamedStoredProcedureQueries({
    @NamedStoredProcedureQuery(name="REGISTER_NEW_EMP",
								procedureName="SPRING_BOOT_PKG.REGISTER_NEW_EMP",
								parameters={
    		                         @StoredProcedureParameter(mode=ParameterMode.IN,name="inParam1",type=String.class)}),
    		                         
@NamedStoredProcedureQuery(name="REGISTER_NEW_EMP",
			       procedureName="SPRING_BOOT_PKG.REGISTER_NEW_EMP",
			       parameters={@StoredProcedureParameter(mode=ParameterMode.IN,name="inParam1",type=String.class),
			       			   @StoredProcedureParameter(mode=ParameterMode.OUT,name="inParam1",type=String.class)})
})*/
@Repository
public class SPRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static Logger log = Logger.getLogger( SPRepository.class ); 
	
	//for login
	public String login(String email,String password)
	{
		log.info("inside login dao");
		log.info("email in dao :"+email+"password in dao :"+password);
		
	    String procedure = "{CALL Claims_pkg.check_table_data(?,?,?)}";

	    Connection conn = null;
		CallableStatement cStmtObject=null;
		String result = null;
		try{
			conn = jdbcTemplate.getDataSource().getConnection();
			cStmtObject = (java.sql.CallableStatement)conn.prepareCall(procedure);
			cStmtObject.setString(1,email);
			cStmtObject.setString(2,password);
			
			cStmtObject.registerOutParameter(3,OracleTypes.VARCHAR);
			cStmtObject.execute();
			result = cStmtObject.getString(3);
			log.info("result in dao :: "+result);
			//String query = "select case when count(*) = 1 then 'Y' else 'Password is incorrect' end  from app.login_table  where userid = '?' and password ='?'";
		}
		catch(Exception ie)
		{
			ie.printStackTrace();
		}
		return result;
	}
	
	//for registering new emp
	public int register(Register register) throws SQLException
	{
		log.info("inside register() of dao");
		
		ResultSet rs = null;
		Connection con = jdbcTemplate.getDataSource().getConnection();
		//CallableStatement statement = con.prepareCall("{CALL SPRING_BOOT_APP.SAVE_REGISTER_NEW(?,?,?,?,?,?)}");
		
		String query = "insert into app.login_table(userid,password,email,phone)"+" values (?,?,?,?)";
		
		int count = jdbcTemplate.update(query, register.getUserid(),register.getPassword(),register.getEmail(),register.getPhone());
		log.info("count in dao :"+count);
		return count;
	}
	
	public Register findEmpById(String email) throws SQLException 
	{
		
	/*	Register register = new Register();
		register.setName("gayathri");
		register.setEmailId("shgdhsgahdghj");
		register.setPhoneNo("9090878656");
		register.setPassword("oiqow87sgdfg");
		return register;*/
		return jdbcTemplate.queryForObject("select userid,password,email,phone  from app.login_table  where email = ?", new Object[] { email },
				new BeanPropertyRowMapper<Register>(Register.class));
		
	}
	

}	
	
//---------------------------------------------------------------
	//extra operations
	/*public void save(Customer customer)
	{
		 System.out.println(" inside save dao");
	     String sqlInsert = "INSERT INTO customer (cust_id, name, email_id, dob)" + " VALUES (?, ?, ?, ?)";
	     jdbcTemplate.update(sqlInsert, customer.getCustId(), customer.getName(), customer.getEmailId(), customer.getDob());
	}
	public void delete(String id)
	{
		String sqlDelete = "Delete customer where cust_id='1'";
        jdbcTemplate.update(sqlDelete);
         
	}
	
	public void update(Customer customer)
	{
		String sqlUpdate = " UPDATE CUSTOMER SET EMAIL_ID =? where name=?";
        jdbcTemplate.update(sqlUpdate,customer.getEmailId(),customer.getName());
	}*/
	


