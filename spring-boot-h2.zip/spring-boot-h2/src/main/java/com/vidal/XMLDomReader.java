package com.vidal;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XMLDomReader {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException
	{
		List<Employee> employees = parseXMLToDTO();
		System.out.println("employees :: "+employees);
	}
	
	private static List<Employee> parseXMLToDTO() throws ParserConfigurationException, SAXException, IOException
	{
	List<Employee> aList = new ArrayList<Employee>();
	Employee employee = null;
	String firstName = null;
	String lastName = null;
	String location = null;
	String mobile = null;
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	DocumentBuilder builder = factory.newDocumentBuilder();
	Document document = builder.parse(new File("src/main/java/company.xml"));
	document.getDocumentElement().normalize();
	Element root = document.getDocumentElement();
	System.out.println("node name :: "+root.getNodeName());// prints employee
	NodeList nodeList = document.getElementsByTagName("employee");
	System.out.println("nodelist :: "+nodeList.getLength()); // prints 3
	if(document.hasChildNodes())
	{
		System.out.println("inside printnode caller method");
		printNote(document.getChildNodes());
	}
	for(int i=0;i<nodeList.getLength();i++)
	{
		Node node = nodeList.item(i);
		System.out.println("::");//separator
		if(node.getNodeType()==Node.ELEMENT_NODE)
		{
			//print all employee's detail
			Element element = (Element) node;
			System.out.println("Employee id :: "+element.getAttribute("id"));
			firstName = element.getElementsByTagName("firstName").item(0).getTextContent();
			lastName = element.getElementsByTagName("lastName").item(0).getTextContent();
			location = element.getElementsByTagName("location").item(0).getTextContent();
			mobile = element.getElementsByTagName("mobile").item(0).getTextContent();
			System.out.println("First name :: "+firstName+"Last name :: "+lastName+"Location :: "+location);
			
			employee = new Employee();
			employee.setId(Integer.parseInt(element.getAttribute("id")));
			employee.setFirstName(element.getElementsByTagName("firstName").item(0).getTextContent());
			employee.setLastName(element.getElementsByTagName("lastName").item(0).getTextContent());
			employee.setLocation(element.getElementsByTagName("location").item(0).getTextContent());
			aList.add(employee);
		}
		//write your code here inside for loop
		if(firstName.equals("David") && mobile.equals("8987676565"))
		{
			//write condition here 
		}
	}
	return aList;
	}//end of parseXMLtoDTO()
	
	
	//2nd method
	private static void printNote(NodeList nodeList) {
		for (int count = 0; count < nodeList.getLength(); count++) {
			Node tempNode = nodeList.item(count);
			// make sure it's element node.
			if (tempNode.getNodeType() == Node.ELEMENT_NODE) {

				// get node name and value
				System.out.println("\nNode Name =" + tempNode.getNodeName());
				System.out.println("Node Value =" + tempNode.getTextContent());

				if (tempNode.hasAttributes()) {

					// get attributes names and values
					NamedNodeMap nodeMap = tempNode.getAttributes();
					System.out.println("inside tempnode has Attribute()");
					for (int i = 0; i < nodeMap.getLength(); i++) {
						System.out.println("nodemap if");
						Node node = nodeMap.item(i);
						System.out.println("attr name : " + node.getNodeName());
						System.out.println("attr value : "
								+ node.getNodeValue());
					}
				}
				if (tempNode.hasChildNodes()) {
					// loop again if has child nodes
					printNote(tempNode.getChildNodes());
				}
				System.out.println("Node Name =" + tempNode.getNodeName());
			}

		}
	}
}
	//  }
//}
