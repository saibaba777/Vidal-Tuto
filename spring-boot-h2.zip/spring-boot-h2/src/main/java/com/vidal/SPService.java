package com.vidal;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
//import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;


@Service
public class SPService {
	
	@Autowired
	SPRepository spRepo ;
	private static Logger log = Logger.getLogger( SPService.class ); 
	
	
	//user login
	public String login(String email,String password)
	{
		log.info("email in service :"+email+"password in service :"+password);
		String result = spRepo.login(email,password);
		return result;
	}
	//----------------------------------------------
	//for registering new one
		public int register(Register register) throws SQLException
		{
			log.info("inside register() service ");
			int count = 0;
			count = spRepo.register(register);
			return count;
		}
		//-----------------------------------------------------
	//find emp by email id
	public Register findEmpById(String email) throws SQLException {
		Register register = null;
		register = spRepo.findEmpById(email);
		return register;
	}
		
	//--------------------------------------------------------
	//studentlogin
/*	public String studentlogin(String email,String password)
	{
		log.info("student email in service :"+email+"student password in service :"+password);
		String result = spRepo.studentlogin(email,password);
		return result;
	}*/
	
//-------------------------------------------------------------------------------	
	/*//one user based on id
	public void update(Customer customer)
	{
		spRepo.update(customer);
	}
	
	//saveuser
	public void addUser(Customer customer)
	{
		System.out.println("inside add user service");
		spRepo.save(customer);
	}
	//deleteuser
	public void delete(String id)
	{
		spRepo.delete(id);
	}*/

	
}
