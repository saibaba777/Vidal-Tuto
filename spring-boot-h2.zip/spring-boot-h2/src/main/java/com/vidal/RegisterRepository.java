/*
package com.vidal;

import java.util.List;

import javax.print.DocFlavor.READER;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


public interface RegisterRepository extends JpaRepository<Register, Long>
{

	//@Query("select r.name from user1 r where r.email=? and r.password=?")
	List<Register> getUserName(String email,String password);
	
	*//****************************login validation with email & password*************************//*
	//@Query("select case when count(*)>=1 then 'Y' else 'Invalid Login.' end from user1 where email=? and password=?")
	List<Register> getValidLogin(String email,String password);
	
	*//****************************find user by EmailId******************************************//*
//	@Query("select r.userid,r.name,r.email,r.phone,r.password, from Register r where r.email=?") -- working
//	@Query(value="select * from user1 where email=?",nativeQuery = true)
	List<Register> getDataByEmail(String email);
	
	*//**************************** insert /register new user working ***********************************//*
//	@Query("insert into register values(?,?,?,?)")
	//@Transactional//in case spring based transaction
	//@Modifying//in case of insert/update query// VO input not working
	//@Query(value="insert into Register(userid,name,email,phone,password) VALUES (:userid,:name,:email,:phone,:password)",nativeQuery=true)
	//int addNewUser(double userid,String name,String email,String phone,String password);
	
	*//**************************** register new user / inser query*********************************//*
//	@Query("insert into register(userid,name,password,email,phone) VALUES (:userid,:name,:password,:email,:phone)")
//	int addNewUSer(@Param("userid")Long userid,@Param("name")String name,@Param("password")String password,@Param("email")String email,@Param("phone")String phone);
	//select name from register where userid=705 and password='password5'; ==working
	//insert into register(userid,name,password,email,phone)  values (705,'kite','password5','kite@gmail.com','9090897867');
}

  















*/