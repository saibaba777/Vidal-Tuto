/*package dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.AppUser;
import model.Gender;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;

import formbean.AppUserFormBean;

@Repository
public class AppUserDAO {

	@Autowired
	private PasswordEncoder passwordEncoder;
	
	private static final Map<Long, AppUser> USERS_MAP = new HashMap<Long, AppUser>();

	static {
		initData();
	}

	public static void initData() {
		String encrytedPassword = "";
		
		AppUser appUser = new AppUser(1L, "sagrika", "SAGRIKA", "DAS", true, Gender.FEMALE, "sagrika.das@gmail.com", "IN", encrytedPassword);
		AppUser appUser2 = new AppUser(2L, "sai", "SAI", "RAVAL", true, Gender.MALE, "sai.raval@gmail.com", "IN", encrytedPassword);
		
		USERS_MAP.put(appUser.getUserId(), appUser);
		USERS_MAP.put(appUser2.getUserId(), appUser2);
	}
	public Long getMaxUserId()
	{
		long max = 0;
		for(Long id : USERS_MAP.keySet())
		{
			if(id>max)
				max = id;
		}
		return max;
	}
	public AppUser findAppUserByName(String userName)
	{
		Collection<AppUser> appUsers = USERS_MAP.values();
		for(AppUser user : appUsers)
		{
			if(user.getUserName().equals(userName))
			{return user;}
		}
		return null;
	}
	public AppUser findAppUserByEmail(String email)
	{
		Collection<AppUser> appUsers = USERS_MAP.values();
		for(AppUser user : appUsers)
		{
			if(user.getEmail().equals(email))
			{return user;}
		}
		return null;
	}
	public List<AppUser> getAppUsers()
	{
		List<AppUser> list = new ArrayList<AppUser>();
		list.addAll(USERS_MAP.values());
		return list;
	}
	public AppUser createAppUser(AppUserFormBean form)
	{
		Long userId = this.getMaxUserId()+1;
		String encrytedPassword = this.passwordEncoder.encode(form.getPassword());
		
		AppUser appUser = new AppUser(userId, form.getUserName(), form.getFirstName(), form.getLastName(), false, form.getGender(), form.getEmail(), form.getCountryCode(), encrytedPassword);
		USERS_MAP.put(userId, appUser);
		
		return appUser;
	}
	
}
*/