/*package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Country;

import org.springframework.stereotype.Repository;

@Repository
public class CountryDAO {

	private static final Map<String, Country> COUNTRY_MAP = new HashMap<String, Country>();

	static {
		initData();
	}

	public static void initData() {
		
		Country country1 = new Country("FR", "France");
		Country country2 = new Country("RU", "Russia");
		Country country3 = new Country("US", "US");
		Country country4 = new Country("EN", "England");
		Country country5 = new Country("VN", "Vietnam");
		
		COUNTRY_MAP.put(country1.getCountryCode(), country1);
		COUNTRY_MAP.put(country2.getCountryCode(), country2);
		COUNTRY_MAP.put(country3.getCountryCode(), country3);
		COUNTRY_MAP.put(country4.getCountryCode(), country1);
		COUNTRY_MAP.put(country5.getCountryCode(), country5);
		
	}
	
	public Country findCountryByCode(Country country)
	{
		return COUNTRY_MAP.get(country.getCountryCode());
	}
	public List<Country> getAllCountries()
	{
		List<Country> list = new ArrayList<Country>();
		list.addAll(COUNTRY_MAP.values());
		return list;
	}
}
*/